# AI 对话与控制 - Seed / AI Chat and Control - Seed

解压后将整个文件夹拖入 ROBO 拓展中心。请使用与本包配套、支持 hostApi 2 的基础版。
Extract and drop this whole folder into ROBO Extension Center. Requires the matching hostApi 2 base.

双击 tutorial.html 查看离线接入教程。配置使用自己的账户和密钥。移除后重装不恢复旧记录。
Open tutorial.html for setup. Use your own accounts and keys. Removal followed by installation starts fresh.

版本 / Version: 1.1.0

## 查询方式 / Query flow

普通联网问题默认只调用一次搜索，直接显示带来源的回答，不再逐个下载网页并二次总结。明确地点的天气、餐厅推荐等简单问题会直接进入搜索；需要上下文、操作工具或深入核实时，仍会先判断需求。查询阶段最多等待 30 秒，简单问题以约 10 秒内返回文字结果为目标，实际时间受模型与网络影响；不包含语音识别和播报。

Ordinary web questions use one search request and return its cited answer without downloading every page or running a second summary. Self-contained weather and restaurant queries can go directly to search; contextual questions, actions and explicit verification still use the planning flow. The search phase has a 30-second limit. Simple questions target a text result within about 10 seconds, depending on the model and network; speech recognition and playback are additional.
