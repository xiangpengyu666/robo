'use strict';
(() => {
  class RoboGmailUI {
    constructor(api, host) {
      this.api = api; this.data = {}; this.revision = -1; this.pending = 0;
      this.notice = ''; this.clientDraft = false; this.consentDraft = false; this.connectingAction = false;
      this.card = document.createElement('details'); this.card.id = 'gmailSettingsSection';
      this.card.className = 'setting-group gmail-settings';
      this.card.innerHTML = `<summary><span class="setting-icon" aria-hidden="true">✉</span><strong>Gmail</strong><span id="gmailConnectionState">未连接</span></summary>
        <div class="setting-content gmail-content">
          <div class="gmail-account"><strong id="gmailAccount">连接 Gmail 接收新邮件提醒</strong><span id="gmailLastChecked"></span></div>
          <div class="gmail-actions"><button id="gmailConnect" class="is-primary" type="button">连接 Gmail</button><button id="gmailCancel" type="button" hidden>取消连接</button><button id="gmailDisconnect" type="button" hidden>断开连接</button><button id="gmailOpenInbox" type="button" hidden>打开邮箱 ↗</button><button id="gmailRefresh" type="button" hidden>检查新邮件</button></div>
          <label class="gmail-consent" for="gmailSummaryConsent"><input id="gmailSummaryConsent" type="checkbox"><span>我同意将邮件正文发送给AI生成语音摘要和日程建议。<small>可随时关闭；日程经我确认后加入待办。</small></span></label>
          <div class="gmail-preferences"><label for="gmailAnnouncements"><span>新邮件播报</span><input id="gmailAnnouncements" type="checkbox"></label><label for="gmailDoNotDisturb"><span>勿扰模式</span><input id="gmailDoNotDisturb" type="checkbox"></label><button id="gmailTest" type="button">测试播报</button></div>
          <p id="gmailNotice" class="gmail-notice" role="status" aria-live="polite"></p><button id="gmailViewSchedules" type="button" hidden>查看日程建议</button>
          <section id="gmailRecentSection" class="gmail-recent" aria-label="最近邮件" hidden><div class="gmail-recent-heading"><strong>最近邮件</strong><span id="gmailPendingCount"></span></div><ul id="gmailRecentList"></ul></section>
          <details id="gmailAdvanced" class="gmail-advanced"><summary>OAuth 配置 <span id="gmailConfigState">未配置</span></summary>
            <form id="gmailConfigForm" autocomplete="off">
              <label for="gmailOAuthJson">Google 桌面应用 OAuth JSON</label><div class="gmail-json-row"><input id="gmailOAuthJson" type="password" autocomplete="new-password" spellcheck="false" maxlength="65536" placeholder="粘贴下载的 JSON 内容"><button id="gmailImportJson" type="button">读取配置</button></div>
              <p class="gmail-subtle">也可直接填写以下两项。配置在本机加密保存。</p>
              <label for="gmailClientId">Client ID</label><input id="gmailClientId" type="password" autocomplete="new-password" spellcheck="false" maxlength="1024" placeholder="…apps.googleusercontent.com">
              <label for="gmailClientSecret">Client secret</label><input id="gmailClientSecret" type="password" autocomplete="new-password" spellcheck="false" maxlength="4096" placeholder="填写桌面应用 Client secret">
              <div class="gmail-config-actions"><button id="gmailSaveConfig" class="is-primary" type="submit">保存 OAuth 配置</button></div>
              <p id="gmailConfigNotice" class="gmail-notice" role="status"></p>
            </form>
            <details id="gmailSetupHelp" class="gmail-help"><summary>首次连接帮助</summary><p>在 Google Cloud 启用 Gmail API，创建“桌面应用”OAuth 客户端，并将自己的 Gmail 账号加入测试用户。下载 JSON 后粘贴到上方。</p><p>只请求邮件只读权限。Testing 模式的授权通常在 7 天后到期，届时需要重新连接。</p><button id="gmailSetup" type="button">打开 Google Cloud 配置 ↗</button></details>
          </details>
        </div>`;
      host.querySelector('#gmailSettingsHost')?.append(this.card);
      this.$ = id => this.card.querySelector(`#${id}`);
      this.secret = window.RoboSecretField.bind(this.$('gmailClientSecret'), {
        reveal: () => this.api.nativeAction({id:'gmail',action:'reveal_key',key:'clientSecret'}),
        onError: message => { this.$('gmailConfigNotice').textContent = message; }
      });
      this.clientIdField = window.RoboSecretField.bind(this.$('gmailClientId'), {
        reveal: async () => ({ ok: true, value: this.data.clientId || '' })
      });
      this.oauthJson = window.RoboSecretField.bind(this.$('gmailOAuthJson'));
      this.$('gmailConfigForm').addEventListener('submit', event => { event.preventDefault(); void this.configure(); });
      this.$('gmailImportJson').addEventListener('click', () => this.importJson());
      this.$('gmailClientId').addEventListener('input', () => { this.clientDraft = true; this.paint(); });
      this.$('gmailClientSecret').addEventListener('input', () => this.paint());
      this.$('gmailConnect').addEventListener('click', () => { void this.connect(); });
      this.$('gmailCancel').addEventListener('click', () => { void this.action({ action: 'cancel' }); });
      this.$('gmailDisconnect').addEventListener('click', () => { void this.action({ action: 'disconnect' }, '已断开 Gmail。'); });
      this.$('gmailOpenInbox').addEventListener('click', () => { void this.open(''); });
      this.$('gmailRefresh').addEventListener('click', () => { void this.action({ action: 'refresh' }, '已检查新邮件。'); });
      this.$('gmailTest').addEventListener('click', () => { void this.action({ action: 'test' }, '测试播报已提交。'); });
      this.$('gmailViewSchedules').addEventListener('click', () => { void window.fangzaiShell?.navigate('todos'); });
      this.$('gmailSetup').addEventListener('click', () => { void this.action({ action: 'setup' }); });
      for (const [id, field] of [['gmailAnnouncements', 'announcementEnabled'], ['gmailDoNotDisturb', 'doNotDisturb']])
        this.$(id).addEventListener('change', () => { void this.action({ action: 'preferences', [field]: this.$(id).checked }); });
      this.$('gmailSummaryConsent').addEventListener('change', () => {
        if (this.data.connected) void this.action({ action: 'preferences', summaryConsent: this.$('gmailSummaryConsent').checked });
        else { this.consentDraft = true; this.paint(); }
      });
      this.card.addEventListener('toggle', () => { if (!this.card.open) this.hide(); });
      this.$('gmailAdvanced').addEventListener('toggle', () => { if (!this.$('gmailAdvanced').open) this.hide(); });
      this.paint();
    }
    effectiveClientId() {
      return (this.clientDraft ? this.clientIdField.getDraft() : this.data.clientId || '').trim();
    }
    hide() {
      this.clientDraft = false; this.clientIdField.reset(Boolean(this.data.clientId));
      this.secret.reset(Boolean(this.data.configured)); this.oauthJson.reset(false);
      this.paint();
    }
    importJson() {
      try {
        const parsed = JSON.parse(this.oauthJson.getDraft()), desktop = parsed?.installed;
        if (!desktop || typeof desktop.client_id !== 'string' || typeof desktop.client_secret !== 'string'
            || !desktop.client_id.trim() || !desktop.client_secret.trim()) throw new Error();
        this.clientIdField.setDraft(desktop.client_id.trim()); this.secret.setDraft(desktop.client_secret);
        this.clientDraft = true; this.oauthJson.reset(false);
        this.$('gmailConfigNotice').textContent = '已读取桌面应用配置，请点击保存。'; this.paint();
      } catch { this.$('gmailConfigNotice').textContent = '请粘贴 Google 下载的“桌面应用”OAuth JSON。'; }
    }
    async configure() {
      const clientId = this.effectiveClientId(), clientSecret = this.secret.getDraft();
      if (!clientId || (!clientSecret.trim() && !(this.data.configured && clientId === this.data.clientId))) { this.$('gmailConfigNotice').textContent = '请填写 Client ID 和 Client secret，或读取桌面应用 JSON。'; return; }
      const result = await this.action({ action: 'configure', clientId, clientSecret }, 'OAuth 配置已保存，可以连接 Gmail。', true);
      if (result?.ok) { this.clientDraft = false; this.hide(); this.$('gmailAdvanced').open = false; }
    }
    async connect() {
      if (!this.data.configured) {
        this.$('gmailAdvanced').open = true; this.$('gmailSetupHelp').open = true;
        this.notice = '请先保存 Google 桌面应用 OAuth 配置。'; this.paint(); this.$('gmailOAuthJson').focus(); return;
      }
      if (!this.$('gmailSummaryConsent').checked) {
        this.notice = '连接前，请明确同意将邮件正文发送给AI生成摘要。'; this.paint(); this.$('gmailSummaryConsent').focus(); return;
      }
      this.connectingAction = true; this.paint();
      try {
        const result = await this.action({ action: 'connect', summaryConsent: true }, 'Gmail 已连接。');
        if (result?.ok) this.consentDraft = false;
      } finally { this.connectingAction = false; this.paint(); }
    }
    async action(input, successNotice = '', form = false) {
      if (this.pending && input.action !== 'cancel') return null;
      this.pending++; this.notice = ''; if (form) this.$('gmailConfigNotice').textContent = ''; this.paint();
      try {
        const result = await this.api.gmailAction(input);
        if (result?.gmail) this.render(result.gmail);
        if (!result?.ok && !result?.cancelled) throw new Error(result?.error || 'Gmail 操作未完成，请重试。');
        if (result?.ok) this.notice = successNotice;
        return result;
      } catch (error) {
        if (form) this.$('gmailConfigNotice').textContent = error.message || 'OAuth 配置未保存，请重试。';
        else this.notice = error.message || 'Gmail 操作未完成，请重试。';
        return null;
      } finally { this.pending--; this.paint(); }
    }
    async open(id) {
      try { const result = await this.api.gmailOpen(id); if (result?.ok === false) throw new Error(result.error); }
      catch { this.notice = '邮箱未能打开，请重试。'; this.paint(); }
    }
    render(data = {}) {
      if ((data.revision ?? 0) < this.revision) return;
      const initial = this.revision < 0;
      this.data = data; this.revision = data.revision ?? 0; this.secret.setSaved(Boolean(data.configured));
      if (!this.clientDraft) this.clientIdField.setSaved(Boolean(data.clientId));
      if (!this.consentDraft) this.$('gmailSummaryConsent').checked = Boolean(data.summaryConsent);
      if (initial && !data.configured) { this.$('gmailAdvanced').open = true; this.$('gmailSetupHelp').open = true; }
      this.paint();
    }
    paint() {
      const data = this.data, connecting = Boolean(data.connecting || this.connectingAction), busy = Boolean(this.pending || connecting || data.checking);
      const preferenceBusy = Boolean(this.pending || connecting);
      const state = connecting ? '正在连接…' : data.needsAuth ? '需重新连接' : data.suspended ? '已暂停' : data.connected ? '已连接' : '未连接';
      this.$('gmailConnectionState').textContent = state;
      this.$('gmailAccount').textContent = data.email || (connecting ? '请在浏览器完成 Google 授权' : '连接 Gmail 接收新邮件提醒');
      this.$('gmailLastChecked').textContent = data.checking ? '正在检查…' : data.lastCheckedAt ? `上次检查 ${this.time(data.lastCheckedAt)}` : '';
      this.$('gmailConnect').hidden = Boolean(data.connected && !data.needsAuth || connecting);
      this.$('gmailConnect').disabled = busy;
      this.$('gmailConnect').textContent = data.needsAuth ? '重新连接 Gmail' : '连接 Gmail';
      this.$('gmailCancel').hidden = !connecting;
      this.$('gmailDisconnect').hidden = !data.connected && !data.needsAuth; this.$('gmailDisconnect').disabled = busy;
      this.$('gmailOpenInbox').hidden = !data.connected; this.$('gmailOpenInbox').disabled = false;
      this.$('gmailViewSchedules').hidden = !(data.scheduleSuggestions || []).some(item => ['pending', 'adding'].includes(item.status));
      this.$('gmailRefresh').hidden = !data.connected; this.$('gmailRefresh').disabled = busy || data.suspended || !data.summaryConsent;
      this.$('gmailAnnouncements').checked = Boolean(data.announcementEnabled); this.$('gmailAnnouncements').disabled = preferenceBusy;
      this.$('gmailDoNotDisturb').checked = Boolean(data.doNotDisturb); this.$('gmailDoNotDisturb').disabled = preferenceBusy;
      this.$('gmailSummaryConsent').disabled = preferenceBusy;
      this.$('gmailTest').disabled = busy || data.testPending || data.speechReady === false || !data.connected || !data.summaryConsent || !data.announcementEnabled || data.doNotDisturb || data.suspended || data.needsAuth;
      this.$('gmailTest').textContent = data.testPending ? '正在播报…' : '测试播报';
      this.$('gmailTest').title = data.doNotDisturb ? '关闭勿扰模式后可测试播报' : !data.announcementEnabled ? '开启新邮件播报后可测试' : data.speechReady === false ? '请先配置机器人音色' : !data.connected || !data.summaryConsent ? '连接 Gmail 并同意摘要后可测试' : '';
      const speechHint = data.speechReady === false && !data.speechError ? '请先在下方设置中配置播报语音' : '';
      this.$('gmailNotice').textContent = [data.error || data.speechError || this.notice || (data.suspended ? '系统恢复后继续检查邮件。' : ''), speechHint].filter(Boolean).join(' ');
      this.$('gmailNotice').hidden = !this.$('gmailNotice').textContent;
      this.$('gmailConfigState').textContent = data.configured ? '已加密保存' : '未配置';
      for (const id of ['gmailClientId', 'gmailClientSecret', 'gmailOAuthJson', 'gmailImportJson', 'gmailSetup']) this.$(id).disabled = busy;
      this.$('gmailClientSecret').placeholder = data.configured ? '已保存；更换配置时填写新值' : '填写桌面应用 Client secret';
      this.$('gmailSaveConfig').disabled = busy || !this.effectiveClientId() || !(this.secret.getDraft().trim() || (data.configured && this.effectiveClientId() === data.clientId));
      const recent = (data.recent || []).slice(0, 5), key = JSON.stringify(recent);
      this.$('gmailRecentSection').hidden = !recent.length;
      this.$('gmailPendingCount').textContent = data.pendingCount ? `${data.pendingCount} 封待播报` : '';
      if (this.recentKey !== key) {
        this.recentKey = key; this.$('gmailRecentList').replaceChildren(...recent.map(item => {
          const row = document.createElement('li'), button = document.createElement('button'); button.type = 'button';
          const from = document.createElement('strong'), subject = document.createElement('span'), meta = document.createElement('small');
          from.textContent = String(item.fromName || '未知发件人').slice(0, 100);
          subject.textContent = String(item.subject || '（无主题）').slice(0, 240);
          meta.textContent = `${this.time(item.receivedAt)} · ${({ pending: '待播报', announced: '已播报', failed: '未播报' })[item.status] || '已收到'}`;
          if (item.error) meta.title = String(item.error).slice(0, 240);
          button.append(from, subject, meta); button.addEventListener('click', () => { void this.open(item.id); }); row.append(button); return row;
        }));
      }
    }
    time(value) {
      const date = new Date(value); return Number.isFinite(date.getTime()) ? date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '';
    }
  }
  window.RoboGmailUI = RoboGmailUI;
})();
