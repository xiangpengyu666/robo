'use strict';
const { createHash } = require('node:crypto');

const clean = (value, limit = 120) => typeof value === 'string' ? Array.from(value.replace(/[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim()).slice(0, limit).join('') : '';
const safeTitle = value => clean(value, 120).replace(/(?:https?:\/\/|www\.)\S+/gi, '').trim();
const ENGLISH_MONTHS = Object.freeze({ january: 1, jan: 1, february: 2, feb: 2, march: 3, mar: 3, april: 4, apr: 4, may: 5, june: 6, jun: 6,
  july: 7, jul: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9, october: 10, oct: 10, november: 11, nov: 11, december: 12, dec: 12 });
function timeZone(value) {
  try { new Intl.DateTimeFormat('en', { timeZone: value }).format(0); return value; } catch { return ''; }
}
function localParts(timestamp, zone) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(timestamp);
  return Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, Number(part.value)]));
}
function validDate(year, month, day) {
  if (!Number.isInteger(year) || year < 1970 || year > 9999 || !Number.isInteger(month) || !Number.isInteger(day)) return false;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function chineseNumber(value) {
  if (/^\d{1,4}$/.test(value)) return Number(value);
  const digits = '零一二三四五六七八九';
  value = value.replace(/〇/g, '零').replace(/两/g, '二');
  if (/^[零一二三四五六七八九]{4}$/.test(value)) return Number([...value].map(char => digits.indexOf(char)).join(''));
  if (/^[零一二三四五六七八九]$/.test(value)) return digits.indexOf(value);
  const match = /^([一二三四五六七八九]?)十([一二三四五六七八九]?)$/.exec(value);
  return match ? (match[1] ? digits.indexOf(match[1]) : 1) * 10 + (match[2] ? digits.indexOf(match[2]) : 0) : NaN;
}
function parseDate(text, receivedAt, zone) {
  if (!Number.isFinite(receivedAt) || receivedAt <= 0) return null;
  const anchor = localParts(receivedAt, zone), value = text.trim(), lower = value.toLowerCase();
  let year = anchor.year, month, day, match;
  if ((match = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(value))) [, year, month, day] = match.map(Number);
  else if ((match = /^([\d零〇一二三四五六七八九]{4})年([\d零〇一二两三四五六七八九十]{1,3})月([\d零〇一二两三四五六七八九十]{1,3})[日号]$/.exec(value))) [, year, month, day] = match.map(chineseNumber);
  else if ((match = /^([\d零〇一二两三四五六七八九十]{1,3})月([\d零〇一二两三四五六七八九十]{1,3})[日号]$/.exec(value))) { month = chineseNumber(match[1]); day = chineseNumber(match[2]); }
  else if ((match = /^([a-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,\s*|\s+)(\d{4})$/i.exec(value))) { year = Number(match[3]); month = ENGLISH_MONTHS[match[1].toLowerCase()]; day = Number(match[2]); }
  else {
    let offset;
    if (['今天', '今日', '当天', 'today'].includes(lower)) offset = 0;
    else if (['明天', '明日', '次日', 'tomorrow'].includes(lower)) offset = 1;
    else if (['后天', '後天'].includes(value)) offset = 2;
    else if ((match = /^(本|这|下)(?:周|星期|礼拜)([一二三四五六日天])$/.exec(value))) {
      const weekday = new Date(Date.UTC(year, anchor.month - 1, anchor.day)).getUTCDay() || 7;
      const target = '一二三四五六日'.indexOf(match[2] === '天' ? '日' : match[2]) + 1;
      offset = target - weekday + (match[1] === '下' ? 7 : 0);
    } else return null; // English “next Friday” and bare weekdays need confirmation.
    const shifted = new Date(Date.UTC(year, anchor.month - 1, anchor.day + offset));
    year = shifted.getUTCFullYear(); month = shifted.getUTCMonth() + 1; day = shifted.getUTCDate();
  }
  return validDate(year, month, day) ? { year, month, day } : null;
}
function parseTime(text) {
  let match, hour, minute;
  if ((match = /^(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m\.?$/i.exec(text.trim()))) {
    hour = Number(match[1]); minute = Number(match[2] || 0);
    return hour >= 1 && hour <= 12 && minute < 60 ? { hour: hour % 12 + (match[3].toLowerCase() === 'p' ? 12 : 0), minute } : null;
  }
  if ((match = /^(?:(上午|早上|早晨|中午|下午|晚上|晚间|凌晨)\s*)?(\d{1,2}):(\d{2})$/.exec(text.trim()))) {
    hour = Number(match[2]); minute = Number(match[3]);
  } else if ((match = /^(上午|早上|早晨|中午|下午|晚上|晚间|凌晨)?([\d零〇一二两三四五六七八九十]{1,3})(?:点|时)(半|[\d零〇一二两三四五六七八九十]{1,3}分?)?$/.exec(text.trim()))) {
    hour = chineseNumber(match[2]); minute = match[3] === '半' ? 30 : match[3] ? chineseNumber(match[3].replace(/分$/, '')) : 0;
    if (!match[1] && hour <= 12) return null; // “三点” does not identify morning/evening.
  } else return null;
  if (match[1]) {
    if (hour < 1 || hour > 12) return null;
    if (['下午', '晚上', '晚间'].includes(match[1])) hour = hour === 12 ? 12 : hour + 12;
    else if (['上午', '早上', '早晨', '凌晨'].includes(match[1])) hour = hour === 12 ? 0 : hour;
    else if (match[1] === '中午' && hour !== 12) return null;
  }
  return Number.isInteger(hour) && hour >= 0 && hour < 24 && Number.isInteger(minute) && minute >= 0 && minute < 60 ? { hour, minute } : null;
}
// Match candidate offsets against civil time. DST gaps and repeated hours require
// an explicit user edit, rather than silently shifting or choosing an offset.
function civilToISO(date, clock, zone) {
  const naive = Date.UTC(date.year, date.month - 1, date.day, clock.hour, clock.minute), candidates = new Set();
  for (const delta of [-36, -24, -12, 0, 12, 24, 36]) {
    const sample = naive + delta * 3600000, parts = localParts(sample, zone);
    const offset = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second) - sample;
    const instant = naive - offset, actual = localParts(instant, zone);
    if (['year', 'month', 'day'].every(key => actual[key] === date[key]) && actual.hour === clock.hour && actual.minute === clock.minute) candidates.add(instant);
  }
  return candidates.size === 1 ? new Date([...candidates][0]).toISOString() : '';
}
function exactDueAt(value, now) {
  if (typeof value !== 'string' || value.length > 40 || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return '';
  const date = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?/.exec(value);
  if (!validDate(Number(date[1]), Number(date[2]), Number(date[3])) || Number(date[4]) > 23 || Number(date[5]) > 59 || Number(date[6] || 0) > 59) return '';
  const instant = Date.parse(value);
  return Number.isFinite(instant) && (now === null || instant > now && instant - now <= 5 * 366 * 86400000) ? new Date(instant).toISOString() : '';
}
function validateSchedule(value, source, { receivedAt, timeZone: requestedZone, now = Date.now() } = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).some(key => !['title', 'evidence', 'dateText', 'timeText'].includes(key))) return null;
  if (typeof value.title !== 'string' || value.title.length > 120 || typeof value.evidence !== 'string' || !value.evidence || value.evidence.length > 1000 || !source.includes(value.evidence)) return null;
  const title = safeTitle(value.title);
  if (!title || !value.evidence.includes(value.title) || title !== clean(value.title, 120)) return null;
  if (typeof value.dateText !== 'string' || value.dateText.length > 40 || typeof value.timeText !== 'string' || value.timeText.length > 40) return null;
  if ((value.dateText && !value.evidence.includes(value.dateText)) || (value.timeText && !value.evidence.includes(value.timeText))) return null;
  const start = source.indexOf(value.evidence), before = source.slice(Math.max(0, start - 300), start).split(/[。！？.!?\n]/).at(-1),
    after = source.slice(start + value.evidence.length, start + value.evidence.length + 300).split(/[。！？.!?\n]/)[0], statement = before + value.evidence + after;
  // A model must not crop off “cancelled”, “not tomorrow”, or a conflicting
  // timezone from the same sentence to make an unsupported proposal look exact.
  if (/取消|已结束|已完成|无需|不要|不必|暂不|待定|可能|也许|或许|尚未确定|尚未确认|如果|假如|不是|改期|延期|推迟/.test(statement)) return null;
  if (/\b(?:cancel(?:led|ed|lation)?|postponed|rescheduled|completed|ended|tentative|unconfirmed|pending|tbd|tbc|maybe|perhaps|might|could|if|unless|assuming|not|never)\b|\b(?:no longer|subject to|provided that|won['’]t|don['’]t|may\s+[a-z])/i.test(statement)) return null;
  const dateIndex = value.evidence.indexOf(value.dateText);
  if (/^(?:\d|[零〇一二两三四五六七八九十])+月/.test(value.dateText) && /(?:\d{4}|[零〇一二三四五六七八九]{4})年$/.test(value.evidence.slice(0, dateIndex))) return null;
  if (/^[a-z]/i.test(value.dateText) && (/[a-z]$/i.test(value.evidence.slice(0, dateIndex)) || /^[a-z]/i.test(value.evidence.slice(dateIndex + value.dateText.length))
    || /\bday\s+after\s+$/i.test(value.evidence.slice(0, dateIndex)))) return null;
  let zone = timeZone(requestedZone) || Intl.DateTimeFormat().resolvedOptions().timeZone;
  let unclearZone = false;
  const zones = [ [/北京时间|中国标准时间/, 'Asia/Shanghai'], [/太平洋时间|Pacific Time/i, 'America/Los_Angeles'], [/美东时间|Eastern Time/i, 'America/New_York'], [/\b(?:UTC|GMT)\b/i, 'UTC'] ];
  const explicitZones = zones.filter(([pattern]) => pattern.test(statement));
  if (/\b(?:UTC|GMT)\s*[+-]|\b(?:EST|EDT|PST|PDT)\b/i.test(statement) || explicitZones.length > 1) unclearZone = true;
  else if (explicitZones.length === 1) zone = explicitZones[0][1];
  const timeIndex = value.evidence.indexOf(value.timeText), croppedMeridiem = /^\d{1,2}:\d{2}$/.test(value.timeText.trim())
    && (/^\s*[ap]\.?m\.?\b/i.test(value.evidence.slice(timeIndex + value.timeText.length)) || /(?:上午|早上|早晨|中午|下午|晚上|晚间|凌晨)\s*$/.test(value.evidence.slice(0, timeIndex)));
  const date = !unclearZone ? parseDate(value.dateText, receivedAt, zone) : null, clock = croppedMeridiem ? null : parseTime(value.timeText);
  const resolved = date && clock ? civilToISO(date, clock, zone) : '';
  // Exact dates in the past are stale, while incomplete timing stays reviewable.
  if (resolved && !exactDueAt(resolved, now)) return null;
  const dueAt = resolved || '';
  return { title, evidence: value.evidence, dateText: clean(value.dateText, 40), timeText: clean(value.timeText, 40), timeZone: zone, dueAt, needsTime: !dueAt };
}
function suggestionId(epoch, messageId) { return createHash('sha256').update(JSON.stringify([epoch, messageId])).digest('hex').slice(0, 32); }
function publicSuggestion(item) {
  return { id: item.id, title: item.title, dueAt: item.dueAt || '', dateText: item.dateText || '', timeText: item.timeText || '', timeZone: item.timeZone,
    needsTime: !item.dueAt, status: item.status, todoId: item.todoId || '', source: { messageId: item.source.messageId, threadId: item.source.threadId || '',
      fromName: clean(item.source.fromName, 100), subject: clean(item.source.subject, 200), receivedAt: item.source.receivedAt } };
}
function restoreSuggestions(items, epoch) {
  if (!Array.isArray(items)) return [];
  return items.filter(item => item && typeof item.id === 'string' && /^[a-f0-9]{32}$/.test(item.id) && item.epoch === epoch && item.source && typeof item.source.messageId === 'string'
    && item.id === suggestionId(epoch, item.source.messageId) && typeof item.title === 'string' && safeTitle(item.title) === item.title && item.title
    && ['pending', 'adding', 'accepted', 'dismissed'].includes(item.status) && typeof item.evidence === 'string' && item.evidence.length <= 1000
    && typeof item.dateText === 'string' && item.dateText.length <= 40 && typeof item.timeText === 'string' && item.timeText.length <= 40 && timeZone(item.timeZone)
    && (!item.dueAt || Boolean(exactDueAt(item.dueAt, null))) && (item.status !== 'adding' || Boolean(item.dueAt))).slice(-40);
}
module.exports = { validateSchedule, exactDueAt, publicSuggestion, suggestionId, restoreSuggestions, safeTitle, timeZone, parseDate, parseTime, civilToISO };
