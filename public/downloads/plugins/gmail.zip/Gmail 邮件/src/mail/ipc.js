'use strict';
const SETUP_URL = 'https://console.cloud.google.com/apis/library/gmail.googleapis.com';
const SAFE_CODES = new Set(['INPUT', 'CONSENT', 'STORAGE', 'DISPOSED', 'CLIENT', 'NETWORK', 'BROWSER', 'TIMEOUT', 'CALLBACK', 'DENIED', 'RESPONSE', 'NEEDS_AUTH', 'PERMISSION', 'API_DISABLED', 'SERVICE', 'RATE_LIMIT', 'UNAUTHORIZED', 'CANCELLED', 'LIMIT']);

function createGmailActions({ gmail, bridge, openExternal, isSuspended = () => false }) {
  const snapshot = () => bridge.snapshot();
  const fail = error => ({ ok: false, error, gmail: snapshot() });
  return {
    async action(input) {
      if (!input || typeof input !== 'object' || Array.isArray(input)) return fail('请选择 Gmail 操作。');
      const action = input.action;
      if (isSuspended() && !['cancel', 'cancel_inbox', 'disconnect'].includes(action)) return fail('锁屏或休眠期间暂停 Gmail 操作。');
      try {
        let result;
        if (action === 'configure') result = await gmail.configure({ clientId: input.clientId, clientSecret: input.clientSecret });
        else if (action === 'connect') result = await gmail.connect({ summaryConsent: input.summaryConsent === true });
        else if (action === 'cancel') result = await gmail.cancelConnect();
        else if (action === 'disconnect') result = await gmail.disconnect();
        else if (action === 'preferences') {
          const changes = {};
          for (const field of ['announcementEnabled', 'doNotDisturb', 'summaryConsent']) {
            if (Object.hasOwn(input, field)) { if (typeof input[field] !== 'boolean') return fail('邮件偏好格式不正确。'); changes[field] = input[field]; }
          }
          if (!Object.keys(changes).length) return fail('请选择要修改的邮件偏好。');
          result = await gmail.updatePreferences(changes);
        } else if (action === 'refresh') result = await gmail.refresh();
        else if (action === 'inbox') {
          if (!['today', 'week'].includes(input.range) || input.refresh !== undefined && typeof input.refresh !== 'boolean'
            || input.preview !== undefined && typeof input.preview !== 'boolean') return fail('请选择今天或近七天。');
          result = await bridge.inbox.read(input.range, { refresh: input.refresh === true, preview: input.preview === true });
        }
        else if (action === 'inbox_progress') {
          if (!['today', 'week'].includes(input.range) || !Number.isSafeInteger(input.readId) || input.readId < 0) return fail('邮件读取标识无效，请刷新重试。');
          result = bridge.inbox.progress(input.range, input.readId);
        }
        else if (action === 'cancel_inbox') { bridge.inbox.cancel(); result = { ok: true }; }
        else if (action === 'accept_schedule') {
          if (typeof input.id !== 'string' || input.title !== undefined && typeof input.title !== 'string' || input.dueAt !== undefined && typeof input.dueAt !== 'string') return fail('请确认邮件安排的事项与时间。');
          result = await bridge.acceptSchedule(input.id, { ...(input.title !== undefined ? { title: input.title } : {}), ...(input.dueAt !== undefined ? { dueAt: input.dueAt } : {}) });
        }
        else if (action === 'dismiss_schedule') result = bridge.dismissSchedule(input.id);
        else if (action === 'test') result = bridge.test();
        else if (action === 'setup') { await openExternal(SETUP_URL); result = { ok: true }; }
        else return fail('不支持的 Gmail 操作。');
        return { ...(result || { ok: true }), gmail: snapshot() };
      } catch (error) { return fail(SAFE_CODES.has(error?.code) ? error.message : 'Gmail 操作未完成，请检查设置后重试。'); }
    },
    async open(id) {
      const state = gmail.snapshot();
      if (isSuspended() || !state.connected || !state.email) return fail('请先连接 Gmail。');
      let destination = 'inbox';
      if (id !== '' && id !== undefined && id !== 'mailbox') {
        if (typeof id !== 'string' || !/^[a-f0-9]{1,64}$/i.test(id)) return fail('邮件标识无效。');
        const record = state.recent.find(item => item.id === id)
          || state.scheduleSuggestions?.find(item => item.source?.messageId === id)?.source || bridge.inbox.find(id);
        if (!record) return fail('这封邮件已不在最近邮件或已保存的安排中，请打开邮箱查看。');
        const thread = record.threadId || record.id || record.messageId;
        if (!/^[a-f0-9]{1,64}$/i.test(thread)) return fail('邮件标识无效。');
        destination = `inbox/${thread}`;
      }
      try { await openExternal(`https://mail.google.com/mail/u/?authuser=${encodeURIComponent(state.email)}#${destination}`); return { ok: true }; }
      catch { return fail('邮箱未能打开，请重试。'); }
    }
  };
}
module.exports = { createGmailActions, SETUP_URL };
