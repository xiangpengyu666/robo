'use strict';

// Gmail supplies an already parsed MIME tree; this module never fetches an
// attachment, follows a link, or instantiates an HTML/document renderer.
const LIMITS = Object.freeze({ depth: 16, parts: 128, headers: 100, headerChars: 8192, bytes: 256 * 1024, bodyChars: 16000 });
const text = value => typeof value === 'string' ? value : '';
const singleLine = value => text(value).replace(/[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim();
const bounded = (value, limit) => value.slice(0, limit).replace(/[\uD800-\uDBFF]$/, '');

function decodeBytes(bytes, charset = 'utf-8') {
  const label = singleLine(charset).toLowerCase();
  const aliases = { utf8: 'utf-8', gb2312: 'gbk', 'gb_2312-80': 'gbk', cp936: 'gbk', latin1: 'windows-1252', 'iso-8859-1': 'windows-1252' };
  try { return new TextDecoder(aliases[label] || label || 'utf-8').decode(bytes); }
  catch { return new TextDecoder('utf-8').decode(bytes); }
}

function decodeHeader(value) {
  let source = text(value).slice(0, LIMITS.headerChars).replace(/\r?\n[ \t]+/g, ' ');
  // RFC 2047 omits whitespace between adjacent encoded words.
  source = source.replace(/(\?=)[ \t]+(?==\?)/g, '$1');
  return singleLine(source.replace(/=\?([^?\s]{1,80})\?([bq])\?([^?]{0,8192})\?=/gi, (whole, charset, encoding, data) => {
    try {
      let bytes;
      if (encoding.toLowerCase() === 'b') {
        if (!/^[a-z0-9+/]*={0,2}$/i.test(data)) return whole;
        bytes = Buffer.from(data, 'base64');
      } else {
        const decoded = data.replace(/_/g, ' '), values = [];
        for (let index = 0; index < decoded.length; index++) {
          if (decoded[index] === '=' && /^[a-f0-9]{2}$/i.test(decoded.slice(index + 1, index + 3))) {
            values.push(parseInt(decoded.slice(index + 1, index + 3), 16)); index += 2;
          } else values.push(decoded.charCodeAt(index) & 255);
        }
        bytes = Buffer.from(values);
      }
      return decodeBytes(bytes, charset);
    } catch { return whole; }
  }));
}

function headersOf(part) {
  const headers = new Map();
  if (!Array.isArray(part?.headers)) return headers;
  for (const header of part.headers.slice(0, LIMITS.headers)) {
    const name = singleLine(header?.name).toLowerCase();
    if (name && !headers.has(name)) headers.set(name, text(header?.value).slice(0, LIMITS.headerChars));
  }
  return headers;
}

function sender(value) {
  const raw = decodeHeader(value), bracketed = raw.match(/^(.*?)<([^<>]+)>/);
  const address = singleLine(bracketed?.[2] || raw.match(/[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[^\s<>(),;]+/i)?.[0] || '').slice(0, 254);
  const validAddress = /^[^\s<>@]+@[^\s<>@]+$/.test(address) ? address : '';
  const name = bounded(singleLine(bracketed ? bracketed[1].trim().replace(/^"(.*)"$/, '$1').replace(/\\(["\\])/g, '$1') : validAddress ? '' : raw), 120);
  return { fromName: name || validAddress || '未知发送人', fromAddress: validAddress };
}

const ENTITIES = Object.freeze({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ensp: ' ', emsp: ' ', thinsp: ' ', ndash: '–', mdash: '—', hellip: '…', bull: '•', middot: '·', copy: '©', reg: '®', trade: '™', euro: '€', pound: '£', yen: '¥', laquo: '«', raquo: '»', lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”', eacute: 'é', Eacute: 'É', aacute: 'á', ouml: 'ö', uuml: 'ü' });
function decodeEntities(value) {
  return value.replace(/&(#(?:x[a-f0-9]+|\d+)|[a-z][a-z0-9]{1,30});/gi, (whole, name) => {
    if (name[0] !== '#') return ENTITIES[name] ?? whole;
    const number = name[1].toLowerCase() === 'x' ? parseInt(name.slice(2), 16) : Number(name.slice(1));
    return Number.isInteger(number) && number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff) ? String.fromCodePoint(number) : '�';
  });
}

function htmlToText(html) {
  // Remove active content and quoted reply containers before deleting tags.
  // Tags are removed before entity decoding so encoded '<script>' stays text.
  return decodeEntities(html.replace(/<!--[\s\S]*?(?:-->|$)/g, '')
    .replace(/<(script|style|head|iframe|object|svg|template)\b[^>]*>[\s\S]*?(?:<\/\1\s*>|$)/gi, '')
    .replace(/<blockquote\b[^>]*>[\s\S]*?(?:<\/blockquote\s*>|$)/gi, '')
    .replace(/<(?:br|hr)\b[^>]*>/gi, '\n').replace(/<\/(?:p|div|li|tr|table|h[1-6]|section|article)\s*>/gi, '\n')
    .replace(/<[^<>]*>/g, ' '));
}

function cleanBody(value) {
  const lines = text(value).replace(/\r\n?/g, '\n').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, '').split('\n');
  const kept = [];
  for (let index = 0; index < lines.length; index++) {
    const raw = lines[index], line = raw.trim();
    if (/^-- ?$/.test(raw) || /^-{2,}\s*(?:original message|forwarded message|原始邮件|转发邮件)\s*-{2,}$/i.test(line)
      || /^On .{1,500} wrote:$/i.test(line) || /^(?:在|于).{1,500}(?:写道|写到)[：:]$/.test(line)) break;
    if (/^(?:Sent from my (?:iPhone|iPad|Android)|发自我的(?:iPhone|iPad|安卓)|来自我的(?:iPhone|iPad))\.?$/i.test(line)
      && lines.slice(index + 1).every(item => !item.trim())) break;
    if (/^(?:From|发件人)[：:]/i.test(line) && lines.slice(index + 1, index + 5).filter(item => /^(?:Sent|Date|To|Subject|发送时间|日期|收件人|主题)[：:]/i.test(item.trim())).length >= 2) break;
    if (/^>+(?:\s|[^\d=])/.test(line)) continue;
    kept.push(raw.replace(/[ \t]+/g, ' ').trimEnd());
  }
  return kept.join('\n').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

function parseMessage(message) {
  if (!message || typeof message !== 'object' || Array.isArray(message) || typeof message.id !== 'string' || !/^[a-z0-9_-]{1,200}$/i.test(message.id)
    || !message.payload || typeof message.payload !== 'object') return null;
  const rootHeaders = headersOf(message.payload), candidates = { plain: [], html: [] };
  let parts = 0, remaining = LIMITS.bytes, truncated = false;
  const seen = new Set();
  function visit(part, depth) {
    if (!part || typeof part !== 'object' || seen.has(part)) return;
    if (depth > LIMITS.depth || parts >= LIMITS.parts) { truncated = true; return; }
    seen.add(part); parts++;
    const headers = headersOf(part), type = singleLine(part.mimeType || headers.get('content-type')).split(';')[0].toLowerCase();
    if (text(part.filename).trim() || /^attachment(?:;|$)/i.test(singleLine(headers.get('content-disposition'))) || part.body?.attachmentId) return;
    if (type === 'text/plain' || type === 'text/html') {
      const encoded = text(part.body?.data);
      if (!encoded) return;
      const charset = headers.get('content-type')?.match(/charset\s*=\s*["']?([^\s;"']+)/i)?.[1] || 'utf-8';
      candidates[type === 'text/plain' ? 'plain' : 'html'].push({ encoded, charset });
    }
    if (Array.isArray(part.parts)) {
      if (part.parts.length > LIMITS.parts) truncated = true;
      for (const child of part.parts.slice(0, LIMITS.parts)) visit(child, depth + 1);
    }
  }
  visit(message.payload, 0);
  function decodeParts(list, html) {
    const pieces = [];
    for (const { encoded, charset } of list) {
      if (remaining <= 0) { truncated = true; break; }
      // Decode a bounded prefix, aligned to base64 quanta. Validate only that
      // prefix so checking a pathological source cannot scan unbounded input.
      const maxEncoded = Math.ceil(remaining / 3) * 4, prefix = encoded.slice(0, maxEncoded);
      if (!/^[a-z0-9_+\/-]*={0,2}$/i.test(prefix) || prefix.length % 4 === 1) continue;
      let bytes = Buffer.from(prefix, 'base64url');
      if (encoded.length > maxEncoded || bytes.length > remaining) truncated = true;
      bytes = bytes.subarray(0, remaining); remaining -= bytes.length;
      const decoded = decodeBytes(bytes, charset), body = cleanBody(html ? htmlToText(decoded) : decoded);
      if (body) pieces.push(body);
    }
    return pieces.join('\n\n');
  }
  // Prefer plain text before allocating the shared decode budget. A large HTML
  // alternative cannot crowd out a later plain-text body in the MIME tree.
  const fullBody = decodeParts(candidates.plain, false) || decodeParts(candidates.html, true);
  if (fullBody.length > LIMITS.bodyChars) truncated = true;
  const internalDate = typeof message.internalDate === 'string' || typeof message.internalDate === 'number' ? Number(message.internalDate) : NaN;
  const headerDate = Date.parse(rootHeaders.get('date') || '');
  const receivedAt = Number.isSafeInteger(internalDate) && internalDate > 0 ? internalDate : Number.isFinite(headerDate) ? headerDate : 0;
  return { id: message.id, ...sender(rootHeaders.get('from')), subject: bounded(decodeHeader(rootHeaders.get('subject')), 500) || '无主题',
    body: bounded(fullBody, LIMITS.bodyChars), receivedAt, truncated };
}

module.exports = { parseMessage };
