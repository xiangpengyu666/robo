'use strict';
const { numericFacts } = require('./summaries');
const { parseDate } = require('./schedule');

const MONTHS = { january: 1, jan: 1, february: 2, feb: 2, march: 3, mar: 3, april: 4, apr: 4, may: 5, june: 6, jun: 6,
  july: 7, jul: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9, october: 10, oct: 10, november: 11, nov: 11, december: 12, dec: 12 };
const DAYS = { monday: 1, mon: 1, tuesday: 2, tue: 2, tues: 2, wednesday: 3, wed: 3, thursday: 4, thu: 4, thurs: 4, friday: 5, fri: 5, saturday: 6, sat: 6, sunday: 7, sun: 7 };
const CURRENCIES = { '$': 'usd', 'us$': 'usd', usd: 'usd', dollar: 'usd', dollars: 'usd', 'us dollar': 'usd', 'us dollars': 'usd', '美元': 'usd',
  '€': 'eur', eur: 'eur', euro: 'eur', euros: 'eur', '欧元': 'eur', '£': 'gbp', gbp: 'gbp', pound: 'gbp', pounds: 'gbp', '英镑': 'gbp',
  '￥': 'cny', cny: 'cny', rmb: 'cny', '人民币': 'cny', '元': 'cny', 'c$': 'cad', cad: 'cad', 'canadian dollar': 'cad', 'canadian dollars': 'cad',
  '加元': 'cad', 'a$': 'aud', aud: 'aud', 'australian dollar': 'aud', 'australian dollars': 'aud', '澳元': 'aud', jpy: 'jpy', yen: 'jpy', '日元': 'jpy' };
const UNITS = { 'business day': 'workday', 'business days': 'workday', 'working day': 'workday', 'working days': 'workday', '工作日': 'workday',
  '个工作日': 'workday', 'calendar day': 'civil-day', 'calendar days': 'civil-day', '个自然日': 'civil-day', '自然日': 'civil-day', day: 'day', days: 'day', '天': 'day',
  hour: 'hour', hours: 'hour', hr: 'hour', hrs: 'hour', '个小时': 'hour', '小时': 'hour', minute: 'minute', minutes: 'minute', min: 'minute', mins: 'minute', '分钟': 'minute',
  second: 'second', seconds: 'second', sec: 'second', secs: 'second', '秒': 'second', week: 'week', weeks: 'week', '周': 'week', '星期': 'week',
  month: 'month', months: 'month', '个月': 'month', year: 'year', years: 'year', '年': 'year', person: 'person', persons: 'person', people: 'person', '人': 'person',
  item: 'item', items: 'item', '件': 'item', time: 'times', times: 'times', '次': 'times', percent: 'percent', '%': 'percent', '％': 'percent',
  kg: 'kg', kilogram: 'kg', kilograms: 'kg', '公斤': 'kg', '千克': 'kg', lb: 'lb', lbs: 'lb', '磅': 'lb' };
const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const alternatives = map => Object.keys(map).sort((a, b) => b.length - a.length).map(escape).join('|');
const NUMBER = '(?:[+-]?\\d{1,40}(?:,\\d{3})*(?:\\.\\d{1,20})?|[零〇一二两三四五六七八九十]{1,3})';
const SCALES = 'thousand|million|billion|trillion|万|亿';
function numberValue(value) {
  if (/^[零〇一二两三四五六七八九十]+$/.test(value)) {
    const digits = '零一二三四五六七八九'; value = value.replace(/〇/g, '零').replace(/两/g, '二');
    const tens = /^([一二三四五六七八九]?)十([一二三四五六七八九]?)$/.exec(value);
    return tens ? String((tens[1] ? digits.indexOf(tens[1]) : 1) * 10 + (tens[2] ? digits.indexOf(tens[2]) : 0))
      : value.length === 1 ? String(digits.indexOf(value)) : null;
  }
  const match = /^([+-]?)(\d+(?:,\d{3})*)(?:\.(\d+))?$/.exec(value);
  if (!match) return null;
  const whole = match[2].replace(/,/g, '').replace(/^0+(?=\d)/, ''), fraction = (match[3] || '').replace(/0+$/, '');
  return `${match[1] === '-' ? '-' : ''}${whole}${fraction ? `.${fraction}` : ''}`;
}

function inboxFacts(value) {
  // These fixed lexical phrases contain 一 as part of a word, not a count.
  // Explicit quantities such as 一封、一个、一小时 remain fully validated.
  value = value.replace(/一些|统一|进一步/g, ' ');
  const supported = [], replace = (expression, extract) => { value = value.replace(expression, (...args) => {
    const facts = extract(...args); if (!facts) return args[0]; supported.push(...facts); return ' ';
  }); };
  // Match explicit currencies and same-unit counts only; never convert money,
  // business days to ordinary days, weeks to days, or ambiguous bare numbers.
  replace(new RegExp(`([+-]?)(${alternatives(CURRENCIES)})\\s*(${NUMBER})(?:\\s*(${alternatives(CURRENCIES)}))?(?:\\s*(${SCALES}))?(?![a-z\\d]|[.,]\\d)`, 'gi'), (raw, sign, currency, number, afterCurrency, scale, offset, source) => {
    if (/[a-z\d.,]/i.test(source[offset - 1] || '')) return null;
    let code = CURRENCIES[currency.toLowerCase()];
    if (afterCurrency) {
      const explicit = CURRENCIES[afterCurrency.toLowerCase()];
      if (currency !== '$' && code !== explicit) return null;
      code = explicit;
    }
    const amount = numberValue(`${sign}${number}`);
    return amount === null ? null : [`money:${code}:${amount}${scale ? `:scale-${scale.toLowerCase()}` : ''}`];
  });
  replace(new RegExp(`(${NUMBER})\\s*(${alternatives(CURRENCIES)})(?:\\s*(${SCALES}))?(?![a-z\\d])`, 'gi'), (_raw, number, currency, scale, offset, source) => {
    if (/[a-z\d.,¥$€£]/i.test(source[offset - 1] || '')) return null;
    const amount = numberValue(number);
    return amount === null ? null : [`money:${CURRENCIES[currency.toLowerCase()]}:${amount}${scale ? `:scale-${scale.toLowerCase()}` : ''}`];
  });
  // Preserve the original word boundaries; a time-shaped identifier such as
  // A10:30B must not become a confirmed clock reading after substring slicing.
  value = value.replace(/\d{4}-\d{1,2}-\d{1,2}|[\d零〇一二三四五六七八九]{4}年[\d零〇一二两三四五六七八九十]{1,3}月[\d零〇一二两三四五六七八九十]{1,3}[日号]|(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:,\s*|\s+)\d{4}|(?:上午|早上|早晨|中午|下午|晚上|晚间|凌晨)\s*\d{1,2}:\d{2}|(?:上午|早上|早晨|中午|下午|晚上|晚间|凌晨)[\d零〇一二两三四五六七八九十]{1,3}(?:点|时)(?:半|[\d零〇一二两三四五六七八九十]{1,3}分?)?|\d{1,2}(?::\d{2})?\s*[ap]\.?m\.?|\d{1,2}:\d{2}/gi, (raw, offset, source) => {
    if (/[a-z\d¥￥$€£]/i.test(source[offset - 1] || '') || /[a-z\d]/i.test(source[offset + raw.length] || '')) return raw;
    const facts = numericFacts(raw);
    if (!facts.length || !facts.every(fact => /^(?:date|time):/.test(fact))) return raw;
    supported.push(...facts);
    for (const fact of facts) { const date = /^date:\d{4}-(\d+)-(\d+)$/.exec(fact); if (date) supported.push(`monthday:${Number(date[1])}:${Number(date[2])}`); }
    return ' ';
  });
  replace(/\b(mon(?:day)?|tue(?:s(?:day)?)?|wed(?:nesday)?|thu(?:rs(?:day)?)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)\b/gi,
    (_raw, weekday) => DAYS[weekday.toLowerCase()] ? [`weekday:${DAYS[weekday.toLowerCase()]}`] : null);
  replace(/(?:周|星期|礼拜)([一二三四五六日天])/g, (_raw, weekday) => [`weekday:${'一二三四五六日'.indexOf(weekday === '天' ? '日' : weekday) + 1}`]);
  replace(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b/gi,
    (raw, month, day, offset, source) => {
      if (/^(?:,\s*|\s+)\d{4}\b/.test(source.slice(offset + raw.length))) return null;
      const date = parseDate(`2000年${MONTHS[month.toLowerCase()]}月${day}日`, Date.UTC(2000, 0, 1), 'UTC');
      return date ? [`monthday:${date.month}:${date.day}`] : null;
    });
  replace(/[\d零〇一二两三四五六七八九十]{1,3}月[\d零〇一二两三四五六七八九十]{1,3}[日号]/g, (raw, offset, source) => {
    if (/[\d零〇一二两三四五六七八九]年\s*$/.test(source.slice(0, offset))) return null;
    const date = parseDate(raw, Date.UTC(2000, 0, 1), 'UTC'); return date ? [`monthday:${date.month}:${date.day}`] : null;
  });
  replace(new RegExp(`(${NUMBER})\\s*(?:-\\s*)?(${alternatives(UNITS)})(?![a-z])`, 'gi'), (_raw, number, unit, offset, source) => {
    if (/[a-z\d.,¥$€£]/i.test(source[offset - 1] || '')) return null;
    const count = numberValue(number); return count === null ? null : [`quantity:${UNITS[unit.toLowerCase()]}:${count}`];
  });
  // Unknown units must keep their original suffix. This closes the old bare
  // number path (for example 3yd -> 3ft) without inventing unit conversions.
  replace(new RegExp(`(${NUMBER})\\s*([a-z]{1,16}|[\\u4e00-\\u9fff]{1,6})(?![a-z])`, 'gi'), (_raw, number, unit, offset, source) => {
    if (/[a-z\d.,¥$€£]/i.test(source[offset - 1] || '')) return null;
    const count = numberValue(number); return count === null ? null : [`literal:${count}:${unit.toLowerCase()}`];
  });
  replace(/[+-]?\d{1,40}(?:,\d{3})*(?:\.\d{1,20})?/g, (raw, offset, source) => {
    if (/[a-z\d.,¥$€£]/i.test(source[offset - 1] || '') || /[a-z\d]|[.,]\d/.test(source.slice(offset + raw.length, offset + raw.length + 2))) return null;
    const number = numberValue(raw); return number === null ? null : [`number:${number}`];
  });
  return [...supported, ...numericFacts(value)];
}

module.exports = { inboxFacts };
