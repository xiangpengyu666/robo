'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const { authorize, refreshTokens, revokeToken, validateClient, requestJson, oauthError } = require('./oauth');
const { parseMessage } = require('./messages');
const { validateSchedule, exactDueAt, publicSuggestion, suggestionId, restoreSuggestions, safeTitle } = require('./schedule');

const API = 'https://gmail.googleapis.com/gmail/v1/users/me/';
const MAX_PENDING = 30, MAX_RECENT = 20, MAX_SEEN = 3000, MAX_HISTORY_PAGES = 100, MAX_RECOVERY_PAGES = 4;
const clone = value => JSON.parse(JSON.stringify(value));
const initial = () => ({ client: null, tokens: null, email: '', cursor: '', connectionEpoch: '', baselineAt: 0, lastCheckedAt: 0,
  needsAuth: false, preferences: { announcementEnabled: true, doNotDisturb: false, summaryConsent: false }, seen: [], pending: [], recent: [], scheduleSuggestions: [], scheduleRevision: 0 });
const validHistoryId = value => typeof value === 'string' && /^\d{1,64}$/.test(value);
const validMessageId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
const safeError = error => error?.publicMailError === true ? error.message : 'Gmail 暂时不可用，请稍后重试。';

function gmailError(data, status) {
  const reason = data?.error?.errors?.[0]?.reason;
  if (status === 401) return oauthError('UNAUTHORIZED', 'Gmail 授权已失效，请重新连接 Google 账户。');
  if (status === 404) return oauthError('NOT_FOUND', 'Gmail 同步记录已过期。');
  if (status === 429 || ['rateLimitExceeded', 'userRateLimitExceeded'].includes(reason))
    return oauthError('RATE_LIMIT', 'Gmail 查询暂受限制，将稍后重试。');
  if (status === 403 && ['accessNotConfigured', 'serviceDisabled'].includes(reason))
    return oauthError('API_DISABLED', '请在 Google Cloud 项目中启用 Gmail API 后重试。');
  if (status === 403) return oauthError('PERMISSION', 'Gmail 读取权限不足，请检查 Google 授权和 Gmail API 配置。');
  return oauthError('SERVICE', 'Gmail 服务暂时不可用，请稍后重试。');
}

class GmailService extends EventEmitter {
  constructor({ directory, safeStorage, fetchImpl = globalThis.fetch, openExternal, now = Date.now,
    pollMs = 20000, requestTimeoutMs = 12000, oauthTimeoutMs = 300000 } = {}) {
    super();
    this.file = path.join(directory, 'gmail-account.json');
    this.safeStorage = safeStorage; this.fetchImpl = fetchImpl; this.openExternal = openExternal; this.now = now;
    this.pollMs = Math.max(100, Number(pollMs) || 20000); this.requestTimeoutMs = requestTimeoutMs; this.oauthTimeoutMs = oauthTimeoutMs;
    this.state = initial(); this.revision = 0; this.generation = 0; this.error = null;
    this.connecting = false; this.checking = false; this.suspended = false; this.disposed = false;
    this.operation = null; this.timer = null; this.failureCount = 0; this.revocations = new Set();
    try {
      if (fs.existsSync(this.file)) {
        const envelope = JSON.parse(fs.readFileSync(this.file, 'utf8'));
        if (envelope.version !== 1 || typeof envelope.encrypted !== 'string' || !envelope.encrypted) throw new Error('format');
        const saved = JSON.parse(safeStorage.decryptString(Buffer.from(envelope.encrypted, 'base64')));
        if (saved.client) saved.client = validateClient(saved.client);
        if (!saved.preferences || !Array.isArray(saved.pending) || !Array.isArray(saved.seen) || !Array.isArray(saved.recent)) throw new Error('format');
        if (saved.tokens && (!saved.client || typeof saved.tokens.accessToken !== 'string' || typeof saved.tokens.refreshToken !== 'string'
          || !saved.tokens.refreshToken || !Number.isFinite(saved.tokens.expiresAt) || !validHistoryId(saved.cursor))) throw new Error('format');
        const defaults = initial();
        this.state = { ...defaults, ...saved, preferences: { ...defaults.preferences,
          announcementEnabled: saved.preferences.announcementEnabled === true,
          doNotDisturb: saved.preferences.doNotDisturb === true, summaryConsent: saved.preferences.summaryConsent === true },
          seen: saved.seen.filter(validMessageId).slice(-MAX_SEEN),
          pending: saved.pending.filter(record => validMessageId(record?.id) && typeof record.body === 'string').slice(-MAX_PENDING),
          recent: saved.recent.slice(0, MAX_RECENT), scheduleSuggestions: restoreSuggestions(saved.scheduleSuggestions, saved.connectionEpoch || String(saved.baselineAt)),
          scheduleRevision: Number.isSafeInteger(saved.scheduleRevision) && saved.scheduleRevision >= 0 ? saved.scheduleRevision : 0 };
      }
    } catch { this.error = '已保存的 Gmail 连接无法读取，请重新配置连接。'; }
    // A saved connection resumes without opening the browser. The first delayed
    // poll leaves time for the app to attach listeners and restore pending audio.
    this.schedule();
  }

  snapshot() {
    const state = this.state;
    return { configured: Boolean(state.client), connected: Boolean(state.tokens && state.email && !state.needsAuth),
      email: state.email, connecting: this.connecting, checking: this.checking, suspended: this.suspended,
      needsAuth: Boolean(state.needsAuth), ...state.preferences, baselineAt: state.baselineAt || null,
      connectionEpoch: state.connectionEpoch || (state.tokens ? String(state.baselineAt) : ''), lastCheckedAt: state.lastCheckedAt || null,
      error: this.error, clientId: state.client?.clientId || '', revision: this.revision, pendingCount: state.pending.length,
      scheduleSuggestions: this.scheduleSuggestions(), scheduleRevision: state.scheduleRevision,
      recent: state.recent.map(record => ({ id: record.id, threadId: record.threadId || '', fromName: record.fromName, subject: record.subject,
        receivedAt: record.receivedAt, announcedAt: record.announcedAt || null, status: record.status,
        error: record.error || null })) };
  }
  result(ok, extras = {}) { return { ok, ...extras, gmail: this.snapshot() }; }
  changed() { this.revision++; this.emit('change', this.snapshot()); }
  assertActive() { if (this.disposed) throw oauthError('DISPOSED', '程序正在退出。'); }
  assertStorage() {
    if (!this.safeStorage?.isEncryptionAvailable?.())
      throw oauthError('STORAGE', '当前系统无法安全保存 Gmail 授权，请检查 Windows 账户后重试。');
  }
  save(next) {
    this.assertStorage();
    try {
      const envelope = { version: 1, encrypted: this.safeStorage.encryptString(JSON.stringify(next)).toString('base64') };
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(envelope), { mode: 0o600 });
      fs.renameSync(`${this.file}.tmp`, this.file);
      this.state = clone(next);
    } catch { throw oauthError('STORAGE', 'Gmail 连接未能保存，请检查磁盘空间后重试。'); }
  }
  cancelOperation() {
    this.generation++; this.operation?.controller.abort(); this.operation?.resolve?.(); this.operation = null;
    this.connecting = false; this.checking = false; clearTimeout(this.timer); this.timer = null;
  }
  begin(kind) {
    this.cancelOperation();
    const operation = { generation: this.generation, controller: new AbortController(), kind };
    operation.done = new Promise(resolve => { operation.resolve = resolve; });
    this.operation = operation; this[kind === 'connect' ? 'connecting' : 'checking'] = true;
    this.error = null; this.changed(); return operation;
  }
  current(operation) { return !this.disposed && !this.suspended && operation.generation === this.generation && !operation.controller.signal.aborted; }
  canPoll() { return !this.disposed && !this.suspended && Boolean(this.state.tokens && this.state.email && !this.state.needsAuth)
    && this.state.preferences.announcementEnabled && this.state.preferences.summaryConsent; }
  schedule(delay) {
    clearTimeout(this.timer); this.timer = null;
    if (!this.canPoll() || this.connecting || this.checking) return;
    const wait = delay ?? Math.min(this.pollMs * Math.pow(2, Math.min(this.failureCount, 4)), 300000);
    this.timer = setTimeout(() => { this.timer = null; this.refresh().catch(() => {}); }, wait);
    this.timer.unref?.();
  }
  finish(operation) {
    if (operation.generation !== this.generation || this.operation !== operation || this.disposed) return;
    this.operation = null; operation.resolve?.(); this.connecting = false; this.checking = false; this.changed(); this.schedule();
  }

  configure(input) {
    this.assertActive(); this.assertStorage(); const client = validateClient(input);
    if (client.clientId === this.state.client?.clientId && !client.clientSecret) client.clientSecret = this.state.client.clientSecret;
    const changedClient = !this.state.client || client.clientId !== this.state.client.clientId || client.clientSecret !== this.state.client.clientSecret;
    const next = changedClient ? { ...initial(), preferences: { ...this.state.preferences }, client } : { ...this.state, client };
    this.save(next); this.cancelOperation(); this.error = null; this.failureCount = 0; this.changed(); this.schedule();
    return this.result(true);
  }

  async connect({ summaryConsent } = {}) {
    this.assertActive(); this.assertStorage();
    if (!this.state.client) throw oauthError('INPUT', '请先配置 Google 桌面应用 OAuth。');
    if (summaryConsent !== true) throw oauthError('CONSENT', '请先同意将邮件正文发送给豆包生成摘要和分类。');
    if (this.suspended) return this.result(false, { error: 'Robo 已暂停，恢复后可连接 Gmail。' });
    const previous = clone(this.state), operation = this.begin('connect');
    try {
      const tokens = await authorize(previous.client, { fetchImpl: this.fetchImpl, openExternal: this.openExternal,
        signal: operation.controller.signal, now: this.now, timeoutMs: this.oauthTimeoutMs, requestTimeoutMs: this.requestTimeoutMs });
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      const session = { tokens, client: previous.client, temporary: true };
      const profile = await this.get('profile', operation, session);
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      if (typeof profile.emailAddress !== 'string' || !/^[^\s@]+@[^\s@]+$/.test(profile.emailAddress)
        || profile.emailAddress.length > 320 || !validHistoryId(profile.historyId))
        throw oauthError('RESPONSE', 'Gmail 返回的账户信息不完整，请重新连接。');
      // Switching/reconnecting creates a fresh baseline and removes any old
      // account's queued mail. Historical inbox messages are never announced.
      this.save({ ...initial(), client: previous.client, tokens: session.tokens, email: profile.emailAddress,
        cursor: profile.historyId, connectionEpoch: crypto.randomUUID(), baselineAt: this.now(), lastCheckedAt: this.now(),
        preferences: { ...this.state.preferences, summaryConsent: true } });
      this.failureCount = 0; this.error = null; this.finish(operation); return this.result(true);
    } catch (error) {
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      if (error?.code === 'CANCELLED') return this.result(false, { cancelled: true });
      this.error = safeError(error); this.finish(operation); return this.result(false, { error: this.error });
    } finally { this.finish(operation); }
  }
  cancelConnect() {
    this.assertActive(); if (this.connecting) { this.cancelOperation(); this.error = null; this.changed(); this.schedule(); }
    return this.result(true);
  }
  disconnect() {
    this.assertActive();
    const token = this.state.tokens?.refreshToken || this.state.tokens?.accessToken;
    // Save before mutating memory so a disk failure cannot silently leave a
    // connection active on the next start after the UI says it was removed.
    this.save({ ...initial(), client: this.state.client, preferences: { ...this.state.preferences } });
    this.cancelOperation(); this.error = null; this.failureCount = 0; this.changed();
    if (token) {
      const controller = new AbortController(); this.revocations.add(controller);
      revokeToken(token, { fetchImpl: this.fetchImpl, signal: controller.signal }).catch(() => {}).finally(() => this.revocations.delete(controller));
    }
    return this.result(true);
  }
  updatePreferences(input) {
    this.assertActive();
    const preferences = { ...this.state.preferences };
    for (const key of ['announcementEnabled', 'doNotDisturb', 'summaryConsent']) {
      if (Object.hasOwn(input || {}, key)) {
        if (typeof input[key] !== 'boolean') throw oauthError('INPUT', 'Gmail 开关参数不正确。');
        preferences[key] = input[key];
      }
    }
    // Withdrawing consent also removes unspoken email bodies from disk.
    const pending = preferences.summaryConsent ? this.state.pending : [];
    const recent = preferences.summaryConsent ? this.state.recent : this.state.recent.map(record => record.status === 'pending'
      ? { ...record, status: 'failed', error: '已取消邮件摘要授权。' } : record);
    this.save({ ...this.state, preferences, pending, recent, scheduleSuggestions: preferences.summaryConsent ? this.state.scheduleSuggestions : [],
      scheduleRevision: this.state.scheduleRevision + (preferences.summaryConsent ? 0 : 1) });
    if (!preferences.announcementEnabled || !preferences.summaryConsent) this.cancelOperation();
    this.error = null; this.changed(); this.schedule(preferences.doNotDisturb ? undefined : 0);
    return this.result(true);
  }

  async renew(operation, session) {
    if (session.renewal) return session.renewal;
    const work = Promise.resolve().then(async () => {
      const tokens = await refreshTokens(session.client, session.tokens.refreshToken,
        { fetchImpl: this.fetchImpl, now: this.now, signal: operation.controller.signal, timeoutMs: this.requestTimeoutMs });
      if (!this.current(operation)) throw oauthError('CANCELLED', '操作已取消。');
      session.tokens = tokens;
      if (!session.temporary) this.save({ ...this.state, tokens });
    });
    session.renewal = work;
    try { await work; } finally { if (session.renewal === work) session.renewal = null; }
  }
  async get(relative, operation, session) {
    if (!this.current(operation)) throw oauthError('CANCELLED', '操作已取消。');
    if (session.tokens.expiresAt <= this.now() + 30000) await this.renew(operation, session);
    for (let attempt = 0; attempt < 2; attempt++) {
      const accessToken = session.tokens.accessToken;
      const { response, data } = await requestJson(this.fetchImpl, `${API}${relative}`, { method: 'GET',
        headers: { authorization: `Bearer ${accessToken}` } },
      { signal: operation.controller.signal, timeoutMs: this.requestTimeoutMs });
      if (!this.current(operation)) throw oauthError('CANCELLED', '操作已取消。');
      if (response.ok && !data?.error) return data;
      if (response.status === 401 && attempt === 0) { if (accessToken === session.tokens.accessToken) await this.renew(operation, session); continue; }
      throw gmailError(data, response.status);
    }
  }
  async history(operation, session) {
    const ids = new Set(), pageTokens = new Set();
    let pageToken = '', cursor = this.state.cursor;
    for (let page = 0; page < MAX_HISTORY_PAGES; page++) {
      const parameters = new URLSearchParams({ startHistoryId: this.state.cursor, labelId: 'INBOX', maxResults: '500' });
      parameters.append('historyTypes', 'messageAdded'); parameters.append('historyTypes', 'labelAdded');
      if (pageToken) parameters.set('pageToken', pageToken);
      const data = await this.get(`history?${parameters}`, operation, session);
      if (!validHistoryId(data.historyId) || (data.history && !Array.isArray(data.history)))
        throw oauthError('RESPONSE', 'Gmail 同步响应不完整，请稍后重试。');
      if (BigInt(data.historyId) > BigInt(cursor)) cursor = data.historyId;
      for (const entry of data.history || []) {
        for (const item of entry.messagesAdded || []) if (validMessageId(item?.message?.id)) ids.add(item.message.id);
        for (const item of entry.labelsAdded || [])
          if (item?.labelIds?.includes('INBOX') && validMessageId(item?.message?.id)) ids.add(item.message.id);
      }
      if (!data.nextPageToken) return { ids: [...ids], cursor, recoveryCutoff: 0 };
      if (typeof data.nextPageToken !== 'string' || pageTokens.has(data.nextPageToken))
        throw oauthError('RESPONSE', 'Gmail 同步分页异常，请稍后重试。');
      pageToken = data.nextPageToken; pageTokens.add(pageToken);
    }
    throw oauthError('LIMIT', 'Gmail 待同步邮件较多，请稍后重试。');
  }
  async recover(operation, session) {
    // An expired history cursor cannot safely replay the entire inbox. Recover
    // only a small recent window, overlapping the last successful check for
    // deliveries that completed around the boundary, and dedupe by Gmail ID.
    const profile = await this.get('profile', operation, session);
    if (!validHistoryId(profile.historyId)) throw oauthError('RESPONSE', 'Gmail 同步信息不完整。');
    const cutoff = Math.max(this.state.baselineAt, (this.state.lastCheckedAt || this.state.baselineAt) - 120000, this.now() - 86400000);
    const ids = new Set(), pageTokens = new Set(); let pageToken = '';
    for (let page = 0; page < MAX_RECOVERY_PAGES; page++) {
      const parameters = new URLSearchParams({ q: `in:inbox -in:spam -in:trash after:${Math.floor(cutoff / 1000)}`, maxResults: '50' });
      if (pageToken) parameters.set('pageToken', pageToken);
      const data = await this.get(`messages?${parameters}`, operation, session);
      if (data.messages && !Array.isArray(data.messages)) throw oauthError('RESPONSE', 'Gmail 补查响应不完整。');
      for (const message of data.messages || []) if (validMessageId(message?.id)) ids.add(message.id);
      if (!data.nextPageToken) break;
      if (typeof data.nextPageToken !== 'string' || pageTokens.has(data.nextPageToken)) throw oauthError('RESPONSE', 'Gmail 补查分页异常。');
      pageToken = data.nextPageToken; pageTokens.add(pageToken);
    }
    return { ids: [...ids], cursor: profile.historyId, recoveryCutoff: cutoff };
  }

  async refresh() {
    this.assertActive();
    if (this.connecting || this.checking) return this.result(false, { busy: true });
    if (!this.canPoll()) return this.result(false, { cancelled: this.suspended,
      error: this.state.needsAuth ? 'Gmail 授权已失效，请重新连接。' : !this.state.tokens ? '请先连接 Gmail。' : '来信播报已暂停。' });
    const operation = this.begin('check'), checkedAt = this.now(),
      session = { tokens: clone(this.state.tokens), client: clone(this.state.client), temporary: false };
    try {
      let batch;
      try { batch = await this.history(operation, session); }
      catch (error) { if (error?.code !== 'NOT_FOUND') throw error; batch = await this.recover(operation, session); }
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      const seen = new Set([...this.state.seen, ...this.state.pending.map(record => record.id)]);
      const candidates = batch.ids.filter(id => !seen.has(id));
      // Bound processing during a flood. The cursor still advances and skipped
      // IDs are remembered, so an oversized burst is not replayed on each poll.
      const selected = candidates.slice(-MAX_PENDING), received = [];
      for (const id of selected) {
        let message;
        try { message = await this.get(`messages/${encodeURIComponent(id)}?format=full`, operation, session); }
        catch (error) { if (error?.code === 'NOT_FOUND') continue; throw error; }
        if (!Array.isArray(message.labelIds) || !message.labelIds.includes('INBOX')
          || message.labelIds.some(label => ['SPAM', 'TRASH', 'SENT'].includes(label))) continue;
        const record = parseMessage(message);
        if (!record || record.id !== id || record.receivedAt <= this.state.baselineAt || record.receivedAt <= batch.recoveryCutoff) continue;
        received.push({ ...record, threadId: validMessageId(message.threadId) ? message.threadId : '', announcementStatus: 'pending', attempts: 0 });
      }
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      received.sort((a, b) => a.receivedAt - b.receivedAt);
      const allSeen = [...this.state.seen, ...candidates];
      const recent = [...received.map(record => ({ id: record.id, threadId: record.threadId, fromName: record.fromName, subject: record.subject,
        receivedAt: record.receivedAt, status: 'pending', error: null })).reverse(), ...this.state.recent].slice(0, MAX_RECENT);
      this.save({ ...this.state, tokens: session.tokens, cursor: batch.cursor, lastCheckedAt: checkedAt,
        seen: [...new Set(allSeen)].slice(-MAX_SEEN), pending: [...this.state.pending, ...received].slice(-MAX_PENDING), recent });
      this.failureCount = 0; this.error = null; this.changed();
      // Queue durable records first; interruption between change and event can
      // be recovered from pending() after restarting the app.
      for (const record of received) {
        if (!this.current(operation)) break;
        this.emit('mail', clone(record));
      }
      this.finish(operation); return this.result(true, { received: received.length });
    } catch (error) {
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      if (['NEEDS_AUTH', 'UNAUTHORIZED'].includes(error?.code)) {
        try { this.save({ ...this.state, needsAuth: true }); }
        catch (storageError) { this.error = safeError(storageError); this.finish(operation); return this.result(false, { error: this.error }); }
      }
      this.failureCount++; this.error = safeError(error); this.finish(operation); return this.result(false, { error: this.error });
    } finally { this.finish(operation); }
  }

  pending() { return clone(this.state.pending); }
  isPending(id) { return this.state.pending.some(record => record.id === id); }
  consumeSuperseded(keepIds) {
    this.assertActive();
    const keep = new Set(keepIds), removed = new Set(this.state.pending.filter(record => !keep.has(record.id)).map(record => record.id));
    if (!removed.size) return 0;
    // This is only the local audio queue. Gmail labels and unread state are never changed.
    this.save({ ...this.state, pending: this.state.pending.filter(record => !removed.has(record.id)),
      recent: this.state.recent.map(record => removed.has(record.id) ? { ...record, status: 'skipped', error: null } : record) });
    this.changed(); return removed.size;
  }
  cancelInbox() {
    if (this.operation?.kind !== 'inbox') return;
    this.cancelOperation(); this.changed(); this.schedule();
  }
  async unread(range, { startAt, endAt, signal } = {}) {
    this.assertActive();
    if (!['today', 'week'].includes(range) || !Number.isFinite(startAt) || !Number.isFinite(endAt) || startAt > endAt)
      throw oauthError('INPUT', '请选择今天或近七天。');
    if (!this.state.tokens || !this.state.email || this.state.needsAuth || this.connecting) throw oauthError('INPUT', '请先连接 Gmail。');
    if (!this.state.preferences.summaryConsent) throw oauthError('CONSENT', '请先同意邮件摘要后查看分类。');
    if (this.suspended || signal?.aborted) return this.result(false, { cancelled: true });
    // Share one authenticated API operation with the poller. This prevents two
    // simultaneous refresh grants from overwriting a newly rotated token.
    const generation = this.generation;
    if (this.operation) {
      let abort;
      const cancelled = new Promise(resolve => { abort = () => resolve(); signal?.addEventListener('abort', abort, { once: true }); });
      try { await Promise.race([this.operation.done, cancelled]); }
      finally { signal?.removeEventListener('abort', abort); }
    }
    if (signal?.aborted || generation !== this.generation || this.disposed || this.suspended || !this.state.preferences.summaryConsent)
      return this.result(false, { cancelled: true });
    const operation = this.begin('inbox'), session = { tokens: clone(this.state.tokens), client: clone(this.state.client), temporary: false };
    const abort = () => operation.controller.abort(); signal?.addEventListener('abort', abort, { once: true });
    try {
      const ids = new Set(), pageTokens = new Set(); let pageToken = '', estimate = 0, more = false;
      for (let page = 0; page < 2 && ids.size < MAX_PENDING; page++) {
        const parameters = new URLSearchParams({ q: `in:inbox is:unread -in:spam -in:trash after:${Math.floor(startAt / 1000) - 1}`,
          maxResults: String(MAX_PENDING - ids.size) });
        if (pageToken) parameters.set('pageToken', pageToken);
        const data = await this.get(`messages?${parameters}`, operation, session);
        if (data.messages && !Array.isArray(data.messages)) throw oauthError('RESPONSE', 'Gmail 未读列表暂不可用。');
        estimate = Math.max(estimate, Number.isSafeInteger(data.resultSizeEstimate) ? data.resultSizeEstimate : 0);
        for (const message of data.messages || []) if (validMessageId(message?.id) && ids.size < MAX_PENDING) ids.add(message.id);
        more = Boolean(data.nextPageToken);
        if (!more) break;
        if (typeof data.nextPageToken !== 'string' || pageTokens.has(data.nextPageToken)) throw oauthError('RESPONSE', 'Gmail 未读列表分页异常。');
        pageToken = data.nextPageToken; pageTokens.add(pageToken);
      }
      const messages = [], selected = [...ids]; let nextIndex = 0, failed = null;
      const workers = Array.from({ length: Math.min(4, selected.length) }, async () => {
        while (!failed && nextIndex < selected.length) {
          const id = selected[nextIndex++]; let raw;
          try { raw = await this.get(`messages/${encodeURIComponent(id)}?format=full`, operation, session); }
          catch (error) { if (error?.code === 'NOT_FOUND') continue; failed = error; return; }
          if (!Array.isArray(raw.labelIds) || !raw.labelIds.includes('INBOX') || !raw.labelIds.includes('UNREAD')
            || raw.labelIds.some(label => ['SPAM', 'TRASH', 'SENT'].includes(label))) continue;
          const message = parseMessage(raw);
          if (message?.id === id && message.receivedAt >= startAt && message.receivedAt <= endAt)
            messages.push({ ...message, threadId: validMessageId(raw.threadId) ? raw.threadId : '' });
        }
      });
      // Four bounded read-only requests reduce popup latency. The session's
      // renewal promise also coalesces simultaneous 401 responses safely.
      await Promise.all(workers);
      if (failed) throw failed;
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      messages.sort((a, b) => b.receivedAt - a.receivedAt);
      return { ok: true, messages, total: more ? Math.max(estimate, messages.length) : messages.length, truncated: more };
    } catch (error) {
      if (!this.current(operation)) return this.result(false, { cancelled: true });
      if (['NEEDS_AUTH', 'UNAUTHORIZED'].includes(error?.code)) this.save({ ...this.state, needsAuth: true });
      throw error;
    } finally { signal?.removeEventListener('abort', abort); this.finish(operation); }
  }
  markAnnounced(id, { ok, error, retry = true, schedule } = {}) {
    this.assertActive(); const record = this.state.pending.find(item => item.id === id);
    if (!record) return this.result(false, { cancelled: true });
    const attempts = (Number(record.attempts) || 0) + 1, remove = ok === true || retry === false || attempts >= 3;
    // Playback providers may include request text in errors. The public recent
    // list uses a fixed failure message rather than exposing mail bodies.
    const message = ok === true ? null : '邮件播报未完成，请打开原邮件查看。';
    const pending = this.state.pending.flatMap(item => item.id !== id ? [item] : remove ? [] : [{ ...item, attempts, announcementStatus: 'failed' }]);
    const recent = this.state.recent.map(item => item.id === id ? { ...item, announcedAt: ok === true ? this.now() : null,
      status: ok === true ? 'announced' : 'failed', error: message } : item);
    let scheduleSuggestions = this.state.scheduleSuggestions, added = null;
    if (ok === true && schedule && this.state.preferences.summaryConsent && this.state.tokens && !this.state.needsAuth) {
      const validated = validateSchedule({ title: schedule.title, evidence: schedule.evidence, dateText: schedule.dateText, timeText: schedule.timeText },
        `${record.subject}\n${record.body}`, { receivedAt: record.receivedAt, timeZone: schedule.timeZone, now: this.now() });
      const epoch = this.state.connectionEpoch || String(this.state.baselineAt), scheduleId = suggestionId(epoch, record.id);
      if (validated && !scheduleSuggestions.some(item => item.id === scheduleId)) {
        added = { ...validated, id: scheduleId, epoch, status: 'pending', todoId: '', source: { messageId: record.id, threadId: record.threadId || '',
          fromName: record.fromName, subject: record.subject, receivedAt: record.receivedAt } };
        scheduleSuggestions = [...scheduleSuggestions, added].slice(-40);
      }
    }
    // Removing the email from the durable audio queue and offering its schedule
    // are one encrypted commit. Interrupted/failed audio cannot create proposals.
    this.save({ ...this.state, pending, recent, scheduleSuggestions, scheduleRevision: this.state.scheduleRevision + (added ? 1 : 0) });
    this.changed(); return this.result(true, { ...(added ? { schedule: publicSuggestion(added) } : {}) });
  }
  scheduleSuggestions() {
    if (!this.state.tokens || this.state.needsAuth || !this.state.preferences.summaryConsent) return [];
    return this.state.scheduleSuggestions.map(publicSuggestion);
  }
  scheduleRecord(id) {
    this.assertActive();
    if (!this.state.tokens || this.state.needsAuth || !this.state.preferences.summaryConsent || this.connecting || this.suspended)
      throw oauthError('INPUT', '请先恢复 Gmail 连接并同意邮件摘要。');
    if (typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw oauthError('INPUT', '邮件安排标识无效。');
    const item = this.state.scheduleSuggestions.find(record => record.id === id);
    if (!item) throw oauthError('INPUT', '这项邮件安排已失效，请检查 Gmail。');
    return item;
  }
  beginSchedule(id, input = {}) {
    const item = this.scheduleRecord(id);
    if (item.status === 'accepted') return { ok: true, alreadyAdded: true, schedule: publicSuggestion(item) };
    if (item.status === 'dismissed') throw oauthError('INPUT', '这项邮件安排已经忽略。');
    // 'adding' is a durable confirmation. A retry after an uncertain commit uses
    // exactly the saved payload and idempotency key, including after restart.
    if (item.status !== 'adding') {
      const title = Object.hasOwn(input, 'title') ? input.title : item.title;
      if (typeof title !== 'string' || title.length > 120 || !safeTitle(title) || safeTitle(title) !== title.trim()) throw oauthError('INPUT', '请填写有效的待办事项名称。');
      const dueAt = exactDueAt(Object.hasOwn(input, 'dueAt') ? input.dueAt : item.dueAt, this.now());
      if (!dueAt) throw oauthError('INPUT', '请确认完整的未来日期和具体时间后添加待办。');
      const next = { ...item, title: title.trim(), dueAt, needsTime: false, status: 'adding', confirmedAt: this.now() };
      this.save({ ...this.state, scheduleSuggestions: this.state.scheduleSuggestions.map(record => record.id === id ? next : record), scheduleRevision: this.state.scheduleRevision + 1 });
      this.changed();
    }
    const confirmed = this.state.scheduleSuggestions.find(record => record.id === id);
    return { ok: true, schedule: publicSuggestion(confirmed), input: { title: confirmed.title, dueAt: confirmed.dueAt },
      context: { interactionId: `gmail-schedule:${confirmed.id}`, actionKey: 'accept' } };
  }
  completeSchedule(id, { todoId } = {}) {
    const item = this.scheduleRecord(id);
    if (item.status === 'accepted') return { ok: true, alreadyAdded: true, schedule: publicSuggestion(item) };
    if (item.status !== 'adding') throw oauthError('INPUT', '请先确认这项邮件安排。');
    const next = { ...item, status: 'accepted', todoId: typeof todoId === 'string' ? todoId.slice(0, 128) : '', acceptedAt: this.now() };
    this.save({ ...this.state, scheduleSuggestions: this.state.scheduleSuggestions.map(record => record.id === id ? next : record), scheduleRevision: this.state.scheduleRevision + 1 });
    this.changed(); return { ok: true, schedule: publicSuggestion(next) };
  }
  dismissSchedule(id) {
    const item = this.scheduleRecord(id);
    if (item.status === 'accepted') throw oauthError('INPUT', '这项安排已经加入待办，请在待办中管理。');
    if (item.status === 'adding') throw oauthError('INPUT', '这项安排的添加结果待确认，请重试添加后在待办中管理。');
    if (item.status !== 'dismissed') {
      this.save({ ...this.state, scheduleSuggestions: this.state.scheduleSuggestions.map(record => record.id === id ? { ...record, status: 'dismissed' } : record), scheduleRevision: this.state.scheduleRevision + 1 });
      this.changed();
    }
    return { ok: true };
  }
  suspend() {
    if (this.disposed || this.suspended) return;
    this.suspended = true; this.cancelOperation(); this.changed();
  }
  resume() {
    if (this.disposed) return;
    this.suspended = false; this.changed(); this.schedule(0);
  }
  dispose() {
    this.disposed = true; this.cancelOperation(); this.removeAllListeners();
    for (const controller of this.revocations) controller.abort(); this.revocations.clear();
    this.state = initial();
  }
}

module.exports = { GmailService, gmailError, API, MAX_PENDING };
