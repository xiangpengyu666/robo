'use strict';
const { EventEmitter } = require('node:events');
const { randomUUID } = require('node:crypto');
const { MailSummaries } = require('./summaries');
const { MailInbox } = require('./inbox');

// Gmail shares the existing output queue. Email text never enters task routing
// or conversation history, and no email is marked read or changed in Gmail.
class GmailVoiceBridge extends EventEmitter {
  constructor({ gmail, voice, summaries, createTodo, now = Date.now, timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone }) {
    super(); this.gmail = gmail; this.voice = voice; this.disposed = false;
    this.tickets = new Map(); this.testTicket = null; this.speechError = null;
    this.held = new Set();
    this.createTodo = createTodo; this.now = now; this.accepting = new Map();
    this.summaryTail = Promise.resolve(); this.account = ''; this.voiceRevision = voice.credentialRevision;
    this.inbox = new MailInbox({ gmail, voice, now, timeZone }); this.reconciling = false;
    this.summaries = summaries || new MailSummaries({
      configured: () => Boolean(voice.config?.configured),
      summarize: request => voice.providers.chat(request), now, timeZone
    });
    this.mailChanged = () => this.reconcile();
    this.mailArrived = () => this.inbox.cache.clear();
    this.voiceChanged = () => {
      const signature = `${this.ready()}:${voice.suspended}:${voice.credentialRevision}`;
      if (signature !== this.voiceSignature) { this.voiceSignature = signature; this.reconcile(); }
    };
    gmail.on('change', this.mailChanged); gmail.on('mail', this.mailArrived); voice.on('change', this.voiceChanged);
    this.reconcile();
  }
  ready() { return this.voice.speechReady?.() ?? Boolean(this.voice.config?.ttsKey && this.voice.config?.ttsSpeaker); }
  snapshot() { const state = this.gmail.snapshot(); return { ...state, scheduleSuggestions: state.scheduleSuggestions || [], scheduleRevision: state.scheduleRevision || 0,
    speechReady: this.ready(), speechError: this.speechError, testPending: Boolean(this.testTicket) }; }
  enabled() {
    const state = this.gmail.snapshot();
    return !this.disposed && !this.voice.disposed && !this.voice.suspended && !state.suspended
      && state.connected && !state.connecting && !state.needsAuth && state.summaryConsent && state.announcementEnabled && !state.doNotDisturb && this.ready();
  }
  canManageSchedule() {
    const state = this.gmail.snapshot();
    return !this.disposed && !this.voice.disposed && !state.suspended && state.connected && !state.connecting && !state.needsAuth && state.summaryConsent;
  }
  changed() { if (!this.disposed) this.emit('change', this.snapshot()); }
  reconcile() {
    if (this.disposed || this.reconciling) return;
    this.reconciling = true;
    try {
    const state = this.gmail.snapshot(), account = `${state.clientId}:${state.email || ''}:${state.connected}:${state.connectionEpoch || state.baselineAt || 0}`;
    const changedAccount = account !== this.account, changedVoice = this.voiceRevision !== this.voice.credentialRevision;
    this.account = account; this.voiceRevision = this.voice.credentialRevision;
    if (changedAccount) { this.held.clear(); this.speechError = null; }
    if (changedVoice) this.speechError = null;
    if (changedAccount || changedVoice || !this.canManageSchedule() || this.voice.suspended) this.inbox.cancel({ clear: true });
    if (changedAccount || changedVoice || !this.enabled()) {
      this.invalidate();
      // Revocation, sleep and account changes cancel an in-flight acceptance.
      // Its saved idempotency key still permits a safe retry if already committed.
      if (changedAccount || !this.canManageSchedule()) for (const work of this.accepting.values()) work.controller.abort();
      if (changedAccount || changedVoice || state.connecting || !state.summaryConsent) this.summaries.clear();
    }
    if (!this.enabled()) return;
    const pending = this.gmail.pending().map((message, order) => ({ message, order }))
      .sort((a, b) => b.message.receivedAt - a.message.receivedAt || b.order - a.order).map(item => item.message);
    const latest = pending[0], activeId = this.voice.announcements.active?.id || this.voice.controller.state.announcement?.id;
    const activeTicket = [...this.tickets.values()].find(ticket => ticket.queueId === activeId);
    const keep = new Set([latest?.id, activeTicket?.id].filter(Boolean));
    // Newer mail replaces a waiting notification, while an audible sentence is
    // allowed to finish. Superseded bodies leave the encrypted local queue;
    // their Gmail unread labels remain available to the inbox popup.
    for (const ticket of [...this.tickets.values()]) {
      if (keep.has(ticket.id)) continue;
      ticket.invalidated = true; ticket.abort.abort(); this.tickets.delete(ticket.id);
      this.voice.announcements.remove(item => item.id === ticket.queueId);
    }
    try { this.gmail.consumeSuperseded?.(keep); }
    catch { this.speechError = '邮件播报状态未能保存，请检查本机存储。'; this.changed(); return; }
    for (const message of latest ? [latest] : []) {
      if (this.tickets.has(message.id) || this.held.has(message.id)) continue;
      const ticket = { id: message.id, queueId: `gmail:${randomUUID()}`, abort: new AbortController(), invalidated: false, text: `收到${message.fromName || '未知发件人'}的邮件。主题：${message.subject || '无主题'}` };
      this.tickets.set(message.id, ticket);
      const valid = () => !ticket.invalidated && !ticket.abort.signal.aborted && this.enabled() && this.gmail.isPending(message.id);
      const accepted = this.voice.announcements.enqueue({
        id: ticket.queueId, text: ticket.text, speech: 'tts', cue: 'notification_success', valid,
        prepare: () => {
          // Bound concurrent cloud summaries to one, even if many mail events
          // arrive together. Suspended/revoked tickets never upload their body.
          const work = this.summaryTail.then(async () => {
            if (!valid()) return;
            const result = await this.summaries.summarizeMail(message, { signal: ticket.abort.signal });
            if (valid()) {
              ticket.schedule = typeof this.createTodo === 'function' ? result.schedule : null;
              ticket.text = result.text + (ticket.schedule ? ticket.schedule.needsTime ? '这封邮件有一项安排，时间还不明确。可以在待办日历中确认时间后加入待办。' : '要把这项安排加入待办吗？' : '');
            }
          });
          this.summaryTail = work.catch(() => {}); return work;
        },
        getText: () => ticket.text,
        onSettled: result => this.settled(ticket, result)
      });
      if (!accepted) { this.tickets.delete(message.id); ticket.abort.abort(); }
    }
    this.voice.announcements.pump();
    } finally { this.reconciling = false; }
  }
  settled(ticket, result) {
    if (this.tickets.get(ticket.id) !== ticket) return;
    this.tickets.delete(ticket.id); ticket.abort.abort();
    if (this.disposed || ticket.invalidated || !this.gmail.isPending(ticket.id)) return;
    // Explicit stop and partial playback failures are consumed locally. They
    // must not restart every 20 seconds; the original message remains in Gmail.
    const error = result?.cancelled ? '播报已停止。' : result?.error || '邮件语音未能播放，请检查语音合成设置。';
    let saved;
    try { saved = this.gmail.markAnnounced(ticket.id, { ok: result?.ok === true, error, retry: false, ...(result?.ok === true && ticket.schedule ? { schedule: ticket.schedule } : {}) }); }
    catch { this.held.add(ticket.id); this.speechError = '邮件播报状态未能保存，请检查本机存储。'; this.changed(); return; }
    if (!result?.ok && !result?.cancelled) this.speechError = error;
    else if (result?.ok) this.speechError = null;
    this.changed();
    if (result?.ok === true && saved?.schedule && this.enabled()) this.emit('schedule', saved.schedule);
  }
  pendingSchedule() {
    if (!this.enabled()) return null;
    return [...this.snapshot().scheduleSuggestions].reverse().find(item => ['pending', 'adding'].includes(item.status) && !item.needsTime) || null;
  }
  async acceptSchedule(id, { title, dueAt, signal } = {}) {
    if (this.disposed || signal?.aborted) return { ok: false, cancelled: true };
    if (typeof this.createTodo !== 'function') return { ok: false, error: '待办服务尚未准备好。' };
    if (!this.canManageSchedule()) return { ok: false, error: '请恢复 Gmail 连接与摘要同意后再确认这项安排。' };
    const existing = this.accepting.get(id);
    if (existing) return existing.promise;
    const controller = new AbortController(), aborted = () => controller.abort();
    signal?.addEventListener('abort', aborted, { once: true });
    const entry = { controller, promise: null }, account = this.account;
    // Insert before awaiting; simultaneous voice/UI confirmations share one call.
    this.accepting.set(id, entry);
    entry.promise = Promise.resolve().then(async () => {
      if (controller.signal.aborted || account !== this.account || !this.canManageSchedule()) return { ok: false, cancelled: true };
      let confirmed;
      try {
        confirmed = this.gmail.beginSchedule(id, { ...(title !== undefined ? { title } : {}), ...(dueAt !== undefined ? { dueAt } : {}) });
        if (confirmed.alreadyAdded) return confirmed;
        if (controller.signal.aborted || account !== this.account || !this.canManageSchedule()) return { ok: false, cancelled: true };
        const result = await this.createTodo(confirmed.input, { ...confirmed.context, signal: controller.signal });
        if (controller.signal.aborted || account !== this.account || !this.canManageSchedule()) return { ok: false, cancelled: true };
        if (result?.ok !== true) return { ok: false, error: '待办添加结果未能确认，请重试。' };
        const todoId = result.todo?.id || result.result?.todo?.id || result.resulttodo?.id || result.id;
        return this.gmail.completeSchedule(id, { todoId });
      } catch (error) {
        if (controller.signal.aborted || account !== this.account) return { ok: false, cancelled: true };
        return { ok: false, error: ['INPUT', 'STORAGE', 'DISPOSED'].includes(error?.code) ? error.message : '待办添加结果未能确认，请重试。' };
      }
    }).finally(() => { signal?.removeEventListener('abort', aborted); if (this.accepting.get(id) === entry) this.accepting.delete(id); this.changed(); });
    return entry.promise;
  }
  dismissSchedule(id) {
    if (!this.canManageSchedule()) return { ok: false, error: '请恢复 Gmail 连接与摘要同意后再确认这项安排。' };
    if (this.accepting.has(id)) return { ok: false, error: '待办正在添加，请等待结果。' };
    try { return this.gmail.dismissSchedule(id); }
    catch (error) { return { ok: false, error: ['INPUT', 'STORAGE', 'DISPOSED'].includes(error?.code) ? error.message : '这项邮件安排未能忽略，请重试。' }; }
  }
  invalidate() {
    const tickets = [...this.tickets.values()];
    const activeId = this.voice.controller.state.announcement?.id;
    const partial = this.voice.controller.current?.announcementReceivedAudio
      ? tickets.find(ticket => ticket.queueId === activeId) : null;
    for (const ticket of tickets) { ticket.invalidated = true; ticket.abort.abort(); }
    this.tickets.clear();
    const ids = new Set(tickets.map(ticket => ticket.queueId));
    if (this.testTicket) { this.testTicket.invalidated = true; ids.add(this.testTicket.queueId); this.testTicket = null; }
    this.voice.announcements.remove(item => ids.has(item.id));
    if (ids.has(this.voice.controller.state.announcement?.id)) this.voice.controller.stop();
    if (partial && this.gmail.isPending(partial.id)) {
      // A sentence already sent to a speaker must not restart from the beginning
      // after unlocking or leaving DND. Untouched queued mail still resumes.
      try { this.gmail.markAnnounced(partial.id, { ok: false, retry: false }); }
      catch { this.held.add(partial.id); this.speechError = '邮件播报状态未能保存，请检查本机存储。'; }
    }
  }
  test() {
    if (!this.enabled()) return { ok: false, error: !this.ready() ? '请先在语音服务中配置机器人音色和语音合成密钥。' : '请连接 Gmail、同意邮件摘要并开启播报，关闭勿扰模式。' };
    if (this.testTicket) return { ok: false, error: '已有测试播报等待播放。' };
    const ticket = { queueId: `gmail-test:${randomUUID()}`, invalidated: false }; this.testTicket = ticket;
    this.speechError = null;
    this.voice.announcements.enqueue({ id: ticket.queueId, text: '收到 Robo 的测试邮件。邮件语音播报已就绪。', speech: 'tts', cue: 'notification_success',
      valid: () => !ticket.invalidated && this.enabled(), onSettled: result => {
        if (this.testTicket !== ticket) return;
        this.testTicket = null;
        if (!result?.ok && !result?.cancelled) this.speechError = result?.error || '测试播报失败，请检查语音合成设置。';
        this.changed();
      } });
    this.changed(); return { ok: true };
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true; this.gmail.off('change', this.mailChanged); this.gmail.off('mail', this.mailArrived); this.voice.off('change', this.voiceChanged);
    this.inbox.cancel({ clear: true });
    for (const work of this.accepting.values()) work.controller.abort();
    this.invalidate(); this.summaries.dispose(); this.removeAllListeners();
  }
}
module.exports = { GmailVoiceBridge };
