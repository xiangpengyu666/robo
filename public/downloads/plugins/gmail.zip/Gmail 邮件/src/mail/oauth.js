'use strict';
const http = require('node:http');
const crypto = require('node:crypto');

const AUTHORIZE_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const REVOKE_URL = 'https://oauth2.googleapis.com/revoke';
const GMAIL_SCOPE = 'https://www.googleapis.com/auth/gmail.readonly';
const oauthError = (code, message) => Object.assign(new Error(message), { code, publicMailError: true });

function validateClient(input) {
  const clientId = typeof input?.clientId === 'string' ? input.clientId.trim() : '';
  if (!/^[A-Za-z0-9_.-]+\.apps\.googleusercontent\.com$/.test(clientId) || clientId.length > 256)
    throw oauthError('INPUT', '请填写 Google 桌面应用的 OAuth Client ID。');
  const clientSecret = typeof input?.clientSecret === 'string' ? input.clientSecret.trim() : '';
  if (clientSecret.length > 512 || /\s/.test(clientSecret))
    throw oauthError('INPUT', 'OAuth Client Secret 格式不正确。');
  return { clientId, clientSecret };
}

function failureFor(data, status) {
  const code = typeof data?.error === 'string' ? data.error : '';
  if (code === 'invalid_grant') return oauthError('NEEDS_AUTH', 'Gmail 授权已失效，请重新连接 Google 账户。');
  if (code === 'invalid_client' || code === 'unauthorized_client')
    return oauthError('CLIENT', 'Google OAuth 配置验证失败，请检查是否使用了桌面应用客户端。');
  if (code === 'access_denied') return oauthError('DENIED', '未授予 Gmail 读取权限，请重新连接并允许读取邮件。');
  if (status === 429) return oauthError('RATE_LIMIT', 'Google 授权暂受限制，请稍后重试。');
  return oauthError('NETWORK', 'Google 授权服务暂时不可用，请稍后重试。');
}

async function requestJson(fetchImpl, url, options, { signal, timeoutMs = 12000 } = {}) {
  if (signal?.aborted) throw oauthError('CANCELLED', '操作已取消。');
  const controller = new AbortController();
  let timer, onAbort;
  const cancel = new Promise((_, reject) => {
    onAbort = () => { controller.abort(); reject(oauthError('CANCELLED', '操作已取消。')); };
    signal?.addEventListener('abort', onAbort, { once: true });
    timer = setTimeout(() => { controller.abort(); reject(oauthError('TIMEOUT', '连接 Google 超时，请检查网络或代理。')); }, timeoutMs);
  });
  try {
    return await Promise.race([(async () => {
      const response = await fetchImpl(url, { ...options, redirect: 'error', signal: controller.signal });
      let data;
      try { data = await response.json(); }
      catch { throw oauthError('RESPONSE', 'Google 返回了无法读取的响应，请稍后重试。'); }
      return { response, data };
    })(), cancel]);
  } catch (error) {
    if (['CANCELLED', 'TIMEOUT', 'RESPONSE'].includes(error?.code)) throw error;
    throw oauthError('NETWORK', '未能连接 Google，请检查网络或代理。');
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', onAbort); }
}

async function tokenRequest(fields, options = {}) {
  const { response, data } = await requestJson(options.fetchImpl || globalThis.fetch, TOKEN_URL,
    { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(fields).toString() }, options);
  if (!response.ok || data?.error) throw failureFor(data, response.status);
  if (typeof data?.access_token !== 'string' || !data.access_token || data.access_token.length > 8192
    || /\s/.test(data.access_token) || !Number.isFinite(Number(data.expires_in)) || Number(data.expires_in) <= 0
    || (data.token_type && String(data.token_type).toLowerCase() !== 'bearer'))
    throw oauthError('RESPONSE', 'Google 返回的授权凭据不完整，请重新连接。');
  if (data.scope && !String(data.scope).split(/\s+/).includes(GMAIL_SCOPE))
    throw oauthError('DENIED', '未授予 Gmail 读取权限，请重新连接并允许读取邮件。');
  return { accessToken: data.access_token,
    refreshToken: typeof data.refresh_token === 'string' && data.refresh_token.length <= 8192 ? data.refresh_token : '',
    expiresAt: (options.now || Date.now)() + Math.min(Number(data.expires_in), 86400) * 1000 };
}

function refreshTokens(client, refreshToken, options = {}) {
  if (!refreshToken) throw oauthError('NEEDS_AUTH', 'Gmail 授权已失效，请重新连接 Google 账户。');
  const fields = { client_id: client.clientId, refresh_token: refreshToken, grant_type: 'refresh_token' };
  if (client.clientSecret) fields.client_secret = client.clientSecret;
  return tokenRequest(fields, options).then(tokens => ({ ...tokens, refreshToken: tokens.refreshToken || refreshToken }));
}

async function revokeToken(token, { fetchImpl = globalThis.fetch, timeoutMs = 5000, signal } = {}) {
  if (!token) return;
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), timeoutMs);
  timer.unref?.();
  const cancel = () => controller.abort();
  signal?.addEventListener('abort', cancel, { once: true });
  if (signal?.aborted) controller.abort();
  try {
    if (controller.signal.aborted) return;
    await Promise.race([fetchImpl(REVOKE_URL, { method: 'POST', redirect: 'error', signal: controller.signal,
      headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ token }).toString() }),
    new Promise(resolve => controller.signal.addEventListener('abort', resolve, { once: true }))]);
  } catch { /* The local disconnect takes effect even if Google is unavailable. */ }
  finally { clearTimeout(timer); signal?.removeEventListener('abort', cancel); }
}

// Desktop OAuth uses a one-use loopback listener and the system browser. No
// Gmail credential or token is ever included in the callback page or its URL.
async function authorize(clientInput, { fetchImpl = globalThis.fetch, openExternal, signal,
  now = Date.now, timeoutMs = 300000, requestTimeoutMs = 12000 } = {}) {
  const client = validateClient(clientInput);
  if (typeof openExternal !== 'function') throw oauthError('BROWSER', '无法打开系统浏览器。');
  if (signal?.aborted) throw oauthError('CANCELLED', '连接已取消。');
  const verifier = crypto.randomBytes(48).toString('base64url');
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  const state = crypto.randomBytes(32).toString('base64url');
  let settle, rejectCallback, timer, abortListener, accepted = false, redirectUri;
  const callback = new Promise((resolve, reject) => { settle = resolve; rejectCallback = reject; });
  // Attach rejection handling before opening a browser (which may be slow).
  callback.catch(() => {});
  const page = (res, status, text) => {
    res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store',
      'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'",
      'referrer-policy': 'no-referrer', 'x-content-type-options': 'nosniff' });
    res.end(`<!doctype html><html lang="zh"><meta charset="utf-8"><title>Robo · Gmail</title><body style="font-family:system-ui;padding:48px"><h1>Robo · Gmail</h1><p>${text}</p></body></html>`);
  };
  const server = http.createServer((req, res) => {
    let target;
    try { target = new URL(req.url, redirectUri); } catch { page(res, 400, '无效的授权请求。'); return; }
    if (req.method !== 'GET' || target.pathname !== '/' || req.headers.host !== new URL(redirectUri).host
      || !['127.0.0.1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) {
      page(res, 404, '此地址只用于 Robo 的 Google 授权。'); return;
    }
    const actualState = target.searchParams.get('state') || '';
    const expected = Buffer.from(state), actual = Buffer.from(actualState);
    if (accepted || expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
      page(res, 400, '授权请求不匹配，请返回 Robo 重试。'); return;
    }
    const code = target.searchParams.get('code'), denied = target.searchParams.get('error');
    if (denied) {
      accepted = true; page(res, 403, '授权未完成，可返回 Robo 重新连接。');
      rejectCallback(oauthError('DENIED', 'Google 授权已取消，请重新连接并允许读取邮件。')); return;
    }
    if (!code || code.length > 8192) { page(res, 400, '授权信息不完整，请返回 Robo 重试。'); return; }
    accepted = true; page(res, 200, '授权已收到，请返回 Robo。此窗口可以关闭。'); settle(code);
  });
  server.requestTimeout = 5000;
  server.headersTimeout = 5000;
  try {
    await new Promise((resolve, reject) => {
      server.once('error', () => reject(oauthError('CALLBACK', '无法开启本机授权回调，请检查防火墙后重试。')));
      server.listen(0, '127.0.0.1', resolve);
    });
    redirectUri = `http://127.0.0.1:${server.address().port}/`;
    abortListener = () => rejectCallback(oauthError('CANCELLED', '连接已取消。'));
    signal?.addEventListener('abort', abortListener, { once: true });
    if (signal?.aborted) abortListener();
    timer = setTimeout(() => rejectCallback(oauthError('TIMEOUT', 'Google 授权等待超时，请重新连接。')), timeoutMs);
    const url = new URL(AUTHORIZE_URL);
    for (const [key, value] of Object.entries({ client_id: client.clientId, redirect_uri: redirectUri, response_type: 'code',
      scope: GMAIL_SCOPE, state, code_challenge: challenge, code_challenge_method: 'S256', access_type: 'offline', prompt: 'consent select_account' }))
      url.searchParams.set(key, value);
    try { await Promise.race([Promise.resolve(openExternal(url.toString())), callback.then(() => {})]); }
    catch (error) {
      if (['CANCELLED', 'TIMEOUT', 'DENIED'].includes(error?.code)) throw error;
      throw oauthError('BROWSER', '未能打开系统浏览器，请重试连接。');
    }
    const code = await callback;
    const fields = { client_id: client.clientId, code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: redirectUri };
    if (client.clientSecret) fields.client_secret = client.clientSecret;
    const tokens = await tokenRequest(fields, { fetchImpl, signal, now, timeoutMs: requestTimeoutMs });
    if (!tokens.refreshToken) throw oauthError('NEEDS_AUTH', 'Google 没有返回离线授权，请重新连接并确认授权。');
    return tokens;
  } finally {
    clearTimeout(timer); signal?.removeEventListener('abort', abortListener);
    server.close(); server.closeAllConnections?.();
  }
}

module.exports = { authorize, refreshTokens, revokeToken, validateClient, requestJson, oauthError,
  AUTHORIZE_URL, TOKEN_URL, REVOKE_URL, GMAIL_SCOPE };
