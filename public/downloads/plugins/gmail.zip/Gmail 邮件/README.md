# Gmail 邮件 / Gmail

解压后将整个文件夹拖入 ROBO 拓展中心。请使用与本包配套、支持 hostApi 2 的基础版。
Extract and drop this whole folder into ROBO Extension Center. Requires the matching hostApi 2 base.

双击 tutorial.html 查看离线接入教程。配置使用自己的账户和密钥。移除后重装不恢复旧记录。
Open tutorial.html for setup. Use your own accounts and keys. Removal followed by installation starts fresh.

版本 / Version: 1.1.0
