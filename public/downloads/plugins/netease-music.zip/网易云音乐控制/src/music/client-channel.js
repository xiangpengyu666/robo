'use strict';

// Client-owned playback through its local Chromium API. No DOM, screenshots,
// input events, audio URLs or second player. See THIRD_PARTY_NOTICES.md.
const { execFile } = require('node:child_process');
const path = require('node:path');
const WebSocket = require('ws');
const { externalResourcePath } = require('../runtime-paths');
const fail = (code, userMessage) => Object.assign(new Error(userMessage), { code, userMessage });
const check = signal => { if (signal?.aborted) throw fail('ABORTED', '操作已停止。'); };
const songId = song => {
  const id = String(song?.id || '');
  if (!/^[1-9]\d{0,14}$/.test(id) || !Number.isSafeInteger(Number(id))) throw fail('MUSIC_ID_INVALID', '歌曲编号不完整，尚未换歌。');
  return id;
};

// Discover only already-loaded modules by API shape, rather than depending on
// a particular build's numeric webpack module IDs. Do not inspect user data.
function clientRuntime() {
  if (!Array.isArray(window.webpackJsonp)) throw new Error('unsupported_runtime');
  const slot = Symbol.for('fangzai.music.require');
  let req = window[slot];
  if (!req) {
    const key = 'fangzai_music_control_' + Date.now();
    window.webpackJsonp.push([[key], { [key]: (module, exports, require) => { req = require; } }, [[key]]]);
    Object.defineProperty(window, slot, { value: req, configurable: true });
  }
  if (!req?.c) throw new Error('unsupported_runtime');
  const found = new Set();
  for (const cached of Object.values(req.c)) {
    const e = cached?.exports;
    for (const candidate of [e, e?.a, e?.default]) {
      if (typeof candidate?.getStore === 'function' && typeof candidate?.getDispatch === 'function') found.add(candidate);
    }
  }
  const matches = [...found].filter(value => {
    const s = value.getStore();
    return s?.playing && s?.playingList && Array.isArray(s.playingList.curPlayingList);
  });
  if (matches.length !== 1) throw new Error('unsupported_runtime');
  return matches[0];
}

function clientState() {
  const runtime = CLIENT_RUNTIME();
  const s = runtime.getStore().playing, item = s.curPlaying, track = item?.track || {};
  return { songId: String(item?.resourceId || ''), title: String(track.name || ''),
    artist: (track.artists || track.ar || []).map(a => a.name).join('/'),
    album: String((track.album || track.al || {}).name || ''), state: s.playingState,
    position: s.playingTime, volume: s.playingVolume };
}
const runtimeSource = '(' + clientRuntime.toString() + ')';
const STATE_EXPRESSION = '(' + clientState.toString().replace('CLIENT_RUNTIME', runtimeSource) + ')()';

// The client's own tray Exit workflow flushes state before exiting. Never call
// its lower-level OS exit/restart helpers or imitate a window close button.
function exitRuntime() {
  const runtime = CLIENT_RUNTIME();
  const models = runtime.app?._models?.filter(model => model.namespace === 'app') || [];
  if (models.length !== 1 || typeof models[0].effects?.['app/exitApp'] !== 'function') throw new Error('unsupported_exit');
  return runtime;
}
const exitSource = '(' + exitRuntime.toString().replace('CLIENT_RUNTIME', runtimeSource) + ')';
const EXIT_READY_EXPRESSION = `(()=>{${exitSource}();return true})()`;
const EXIT_EXPRESSION = `(async()=>{const r=${exitSource}();await r.getDispatch()({type:'app/exitApp',payload:{}});return true})()`;

function playExpression(track) {
  songId(track);
  // Payload is serialized as data. Only the fixed action below can be called.
  return `(async()=>{const r=${runtimeSource}();const s=r.getStore();const track=${JSON.stringify(track)};
    const offset=s.playingList.curPlayingList.findIndex(x=>String(x.resourceId)===String(s.playing.curPlaying?.resourceId));
    await r.getDispatch()({type:'playingList/addItemToCurPlayingList',payload:{trackList:[track],
      trackFrom:{text:'Robo点歌',href:'',resourceType:'track',scene:'search',fromInfo:{originalScene:'search',originalResourceType:'track',computeSourceResourceType:'track',sourceData:{}}},
      options:{clear:false,play:true,playId:track.id,offset},triggerScene:'search',triggerAction:'nextPlay'}});return true})()`;
}

async function clientProcess(app, action, { signal, port = 9223 } = {}) {
  check(signal);
  if (!app?.path || path.win32.basename(app.path).toLowerCase() !== 'cloudmusic.exe' || app.args?.length || app.aumid)
    throw fail('MUSIC_CLIENT_INVALID', '网易云客户端入口无法确认，尚未操作。');
  const request = Buffer.from(JSON.stringify({ path: app.path, action, port })).toString('base64');
  const script = path.join(require('robo:package').root, 'payload/netease-client-channel.ps1');
  return new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-RequestBase64', request],
    { windowsHide: true, signal, timeout: 7000, maxBuffer: 32000, encoding: 'utf8' }, (error, stdout) => {
      if (signal?.aborted) return reject(fail('ABORTED', '操作已停止。'));
      try { const value = JSON.parse(stdout.replace(/^\uFEFF/, '')); if (!error && value?.ok) return resolve(value); } catch {}
      reject(fail('MUSIC_CHANNEL_UNAVAILABLE', '暂时无法确认网易云后台连接，尚未换歌。'));
    }));
}

class NetEaseClientChannel {
  constructor({ port = 9223, fetchImpl = fetch, inspect = clientProcess, Socket = WebSocket } = {}) {
    this.port = port; this.fetch = fetchImpl; this.inspect = inspect; this.Socket = Socket;
    this.socket = null; this.identity = null; this.sequence = 0; this.pending = new Map(); this.prepared = null; this.compatible = false;
  }
  get connected() { return this.socket?.readyState === WebSocket.OPEN; }
  get ready() { return this.connected && this.compatible; }
  launchArguments() { return ['--remote-debugging-address=127.0.0.1', `--remote-debugging-port=${this.port}`]; }
  async connect(app, { signal, launch = false } = {}) {
    check(signal);
    if (this.connected && this.identity === app?.path) return;
    this.dispose();
    let state = await this.inspect(app, 'inspect', { signal, port: this.port });
    if (!state.ready && !state.running && launch) {
      await this.inspect(app, 'launch', { signal, port: this.port });
      for (let i = 0; i < 8 && !state.ready; i++) {
        await new Promise(resolve => setTimeout(resolve, 350)); check(signal);
        state = await this.inspect(app, 'inspect', { signal, port: this.port });
      }
    }
    if (!state.ready) throw fail('MUSIC_CHANNEL_RESTART_REQUIRED', state.running
      ? '网易云尚未开启后台点歌连接。请从托盘退出网易云，再让我播放，我会尝试在后台重新连接。'
      : '网易云后台连接尚未就绪，尚未换歌。');
    const signalWithTimeout = signal ? AbortSignal.any([signal, AbortSignal.timeout(2500)]) : AbortSignal.timeout(2500);
    const response = await this.fetch(`http://127.0.0.1:${this.port}/json/list`, { signal: signalWithTimeout, redirect: 'error' });
    if (!response.ok) throw fail('MUSIC_CHANNEL_UNAVAILABLE', '网易云后台连接未响应，尚未换歌。');
    const targets = await response.json();
    const pages = Array.isArray(targets) ? targets.filter(t => t.type === 'page' && String(t.url).startsWith('orpheus://orpheus/')) : [];
    if (pages.length !== 1) throw fail('MUSIC_CHANNEL_TARGET', '无法唯一确认网易云播放页面，尚未换歌。');
    const url = new URL(pages[0].webSocketDebuggerUrl);
    if (url.protocol !== 'ws:' || url.hostname !== '127.0.0.1' || url.port !== String(this.port) || url.username || url.password || !url.pathname.startsWith('/devtools/page/'))
      throw fail('MUSIC_CHANNEL_TARGET', '网易云后台连接地址不符合预期，尚未换歌。');
    check(signal);
    const socket = this.socket = new this.Socket(url.href, { handshakeTimeout: 2500, maxPayload: 1024 * 1024 });
    this.identity = app.path;
    socket.on('message', raw => {
      let value; try { value = JSON.parse(raw.toString()); } catch { return; }
      const pending = this.pending.get(value.id); if (!pending) return;
      if (value.error || value.result?.exceptionDetails) pending.reject(fail('MUSIC_CHANNEL_UNSUPPORTED', '这个网易云版本的后台接口暂不兼容，尚未确认换歌。'));
      else pending.resolve(value.result?.result?.value);
    });
    const disconnected = () => { if (this.socket !== socket) return; this.compatible = false; for (const p of [...this.pending.values()]) p.reject(fail('MUSIC_CHANNEL_DISCONNECTED', '网易云后台连接已断开，播放结果尚未确认。')); };
    socket.on('close', disconnected); socket.on('error', disconnected);
    await new Promise((resolve, reject) => {
      const cleanup = () => { signal?.removeEventListener('abort', abort); socket.removeListener('open', opened); socket.removeListener('error', errored); };
      const opened = () => { cleanup(); resolve(); };
      const errored = () => { cleanup(); reject(fail('MUSIC_CHANNEL_UNAVAILABLE', '网易云后台连接未能建立。')); };
      const abort = () => { cleanup(); socket.terminate(); reject(fail('ABORTED', '操作已停止。')); };
      socket.once('open', opened); socket.once('error', errored); signal?.addEventListener('abort', abort, { once: true });
      if (signal?.aborted) abort();
    });
  }
  evaluate(expression, { signal, timeout = 5000 } = {}) {
    check(signal);
    if (!this.connected) throw fail('MUSIC_CHANNEL_UNAVAILABLE', '网易云后台连接尚未就绪。');
    return new Promise((resolve, reject) => {
      const id = ++this.sequence;
      const finish = (fn, value) => { clearTimeout(timer); signal?.removeEventListener('abort', abort); this.pending.delete(id); fn(value); };
      const abort = () => finish(reject, fail('ABORTED', '操作已停止。'));
      const timer = setTimeout(() => finish(reject, fail('MUSIC_CHANNEL_TIMEOUT', '网易云后台接口响应超时，结果尚未确认。')), timeout);
      this.pending.set(id, { resolve: v => finish(resolve, v), reject: e => finish(reject, e) });
      signal?.addEventListener('abort', abort, { once: true });
      this.socket.send(JSON.stringify({ id, method: 'Runtime.evaluate', params: { expression, returnByValue: true, awaitPromise: true } }), error => {
        if (error) this.pending.get(id)?.reject(fail('MUSIC_CHANNEL_DISCONNECTED', '网易云后台连接已断开。'));
      });
    });
  }
  async read(app, options = {}) {
    await this.connect(app, options);
    try {
      const state = await this.evaluate(STATE_EXPRESSION, options);
      if (typeof state?.songId !== 'string' || ![1, 2].includes(state.state)) throw fail('MUSIC_CHANNEL_UNSUPPORTED', '网易云当前播放状态暂时无法确认。');
      this.compatible = true; return state;
    } catch (error) { this.compatible = false; throw error; }
  }
  async close(app, { signal, guard = async () => check(signal), submitted = () => {} } = {}) {
    try {
      await this.connect(app, { signal, launch: false });
      if (await this.evaluate(EXIT_READY_EXPRESSION, { signal }) !== true) return { supported: false };
    } catch (error) {
      if (signal?.aborted || error.code === 'ABORTED') throw error;
      return { supported: false, reason: error.code };
    }
    await guard(); check(signal); submitted();
    try {
      const accepted = await this.evaluate(EXIT_EXPRESSION, { signal, timeout: 3000 });
      return { supported: true, accepted: accepted === true };
    } catch (error) {
      if (signal?.aborted || error.code === 'ABORTED') throw error;
      // Normal exit can disconnect CDP before its reply arrives. Only the
      // executor's independent process readback may confirm completion.
      return { supported: true, accepted: null, reason: error.code };
    } finally { this.dispose(); }
  }
  async prepare(app, song, { signal } = {}) {
    this.prepared = null; const id = songId(song);
    await this.connect(app, { signal, launch: true });
    const before = await this.read(app, { signal });
    const requestSignal = signal ? AbortSignal.any([signal, AbortSignal.timeout(8000)]) : AbortSignal.timeout(8000);
    const response = await this.fetch('https://music.163.com/api/song/detail?ids=' + encodeURIComponent(JSON.stringify([Number(id)])),
      { signal: requestSignal, headers: { Referer: 'https://music.163.com/' }, redirect: 'error' });
    if (!response.ok) throw fail('MUSIC_DETAIL_FAILED', '歌曲详情暂时无法取得，尚未换歌。');
    const detail = await response.json(), track = detail?.songs?.find(t => String(t.id) === id);
    if (detail.code !== 200 || !track?.name || JSON.stringify(track).length > 100000)
      throw fail('MUSIC_DETAIL_FAILED', '未取得所选歌曲的完整详情，尚未换歌。');
    check(signal); this.prepared = { appPath: app.path, id, track, before, at: Date.now() };
  }
  async play(app, song, options = {}) {
    check(options.signal);
    const ready = this.prepared; this.prepared = null;
    if (!ready || ready.id !== songId(song) || ready.appPath !== app.path || Date.now() - ready.at > 30000)
      throw fail('MUSIC_PREPARE_REQUIRED', '点歌准备已失效，尚未换歌。');
    const current = await this.read(app, options);
    if (current.songId !== ready.before.songId || current.state !== ready.before.state)
      throw fail('MUSIC_CLIENT_CHANGED', '网易云播放状态刚刚发生变化，这次没有换歌。');
    await this.evaluate(playExpression(ready.track), options);
  }
  dispose() {
    this.prepared = null; this.compatible = false;
    for (const p of [...this.pending.values()]) p.reject(fail('MUSIC_CHANNEL_DISCONNECTED', '网易云后台连接已关闭。'));
    const socket = this.socket; this.socket = null; this.identity = null;
    if (socket) socket.terminate();
  }
}
module.exports = { NetEaseClientChannel, STATE_EXPRESSION, EXIT_READY_EXPRESSION, EXIT_EXPRESSION, playExpression, songId };
