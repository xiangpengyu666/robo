'use strict';

const source = value => String(value || '').toLowerCase().replace(/\.exe$/, '');
function samePlayingMedia(expected, current) {
  if (!expected || !current || source(expected.sourceId) !== 'cloudmusic' || source(current.sourceId) !== 'cloudmusic'
    || expected.status !== 'playing' || current.status !== 'playing') return false;
  if (!expected.title || !expected.artist) return false;
  if (current.title !== expected.title || current.artist !== expected.artist) return false;
  return ['songId', 'sessionId', 'album'].every(key => expected[key] == null || expected[key] === ''
    || String(current[key] ?? '') === String(expected[key]));
}

// Music stays owned by the desktop client. This listener owns only a
// robot event; it never waits in, retries or changes the music operation.
class MusicDanceDriver {
  constructor({ playback, behaviors, robot, isBlocked = () => false, canDance = () => true,
    getInteractionId = () => null } = {}) {
    Object.assign(this, { playback, behaviors, robot, isBlocked, canDance, getInteractionId });
    this.current = null; this.generation = 0; this.seen = new Set(); this.cleanups = new Set(); this.disposed = false;
    this.onStarted = event => this.schedule(event);
    this.onInvalidated = () => { void this.cancel('playback_changed'); };
    this.onRobotChanged = () => this.refresh();
    playback?.on?.('playback-started', this.onStarted);
    playback?.on?.('playback-invalidated', this.onInvalidated);
    robot?.on?.('change', this.onRobotChanged);
  }
  blocked() { try { return !!this.isBlocked(); } catch { return true; } }
  admitted(record) { try { return !!this.canDance(record); } catch { return false; } }
  connected() { try { return !this.robot || this.robot.snapshot().state === 'connected'; } catch { return false; } }
  isCurrent(record) {
    return this.current === record && !this.disposed && !record.abort.signal.aborted && record.generation === this.generation
      && (record.behaviorGeneration == null || record.behaviorGeneration === this.behaviors.generation);
  }
  schedule(event) {
    if (this.disposed || !event || typeof event.id !== 'string' || !event.id || this.seen.has(event.id)
      || !['play_song', 'resume'].includes(event.action) || !samePlayingMedia(event.media, event.media)
      || typeof event.appPath !== 'string' || !event.appPath || !Number.isFinite(event.observedAt)) return false;
    this.seen.add(event.id);
    if (this.seen.size > 1000) this.seen.delete(this.seen.values().next().value);
    const cleanup = this.cancel('replaced');
    if (this.blocked() || !this.connected()) return false;
    let interactionId = null;
    try { interactionId = this.getInteractionId(); } catch {}
    const record = { ...event, media: { ...event.media }, id: `music-dance:${event.id}`, generation: this.generation,
      behaviorGeneration: this.behaviors.generation ?? null, interactionId,
      abort: new AbortController(), phase: 'pending' };
    this.current = record;
    // No artificial delay. Drain only a previous robot lease, then recheck the
    // verified song and admit its action while its own music task settles.
    void cleanup.then(() => this.perform(record));
    return true;
  }
  refresh() {
    const record = this.current;
    if (record && (!this.isCurrent(record) || this.blocked() || !this.connected()
      || record.phase === 'playing' && !this.admitted(record))) void this.cancel('blocked');
  }
  async perform(record) {
    try {
      if (!this.isCurrent(record) || this.blocked() || !this.connected() || !this.admitted(record)) return;
      record.phase = 'checking';
      const media = await this.playback.readCurrentPlayback({ appPath: record.appPath, signal: record.abort.signal });
      if (!this.isCurrent(record) || this.blocked() || !this.connected() || !this.admitted(record)
        || !samePlayingMedia(record.media, media) || !this.behaviors.canPlayEvent('蹦迪', { allowTracking: true })) return;
      record.phase = 'playing';
      const motion = await this.behaviors.playEvent('蹦迪', record.id, {
        allowTracking: true, holdAfter: true, signal: record.abort.signal
      });
      if (!this.isCurrent(record)) { await this.behaviors.cancelEvent(record.id); return; }
      if (!motion?.ok) return;
      const result = await motion.done;
      if (result?.ok !== false && this.isCurrent(record) && !this.blocked() && this.connected() && this.admitted(record)
        && this.behaviors.isEventCurrent(record.id)) await this.behaviors.releaseEvent(record.id, { restoreHome: true });
    } catch { /* A failed read or robot action cannot fail or retry music. */ }
    finally {
      if (this.current === record) {
        this.current = null;
        // Clean up only this lease, including an interrupted held pose. A new
        // manual/tracking/result owner is protected by the exact event ID.
        try { await this.behaviors.cancelEvent(record.id); } catch {}
      }
    }
  }
  async cancel(_reason = 'cancelled') {
    const record = this.current; this.current = null; ++this.generation;
    if (record) {
      record.abort.abort();
      const cleanup = Promise.resolve().then(() => this.behaviors.cancelEvent(record.id)).catch(() => {});
      this.cleanups.add(cleanup);
      void cleanup.finally(() => this.cleanups.delete(cleanup));
    }
    // A voice change may have already revoked the record. The following cue
    // still waits for that exact dance's pending STOP before starting its MP3.
    await Promise.all([...this.cleanups]);
  }
  async dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.playback?.removeListener?.('playback-started', this.onStarted);
    this.playback?.removeListener?.('playback-invalidated', this.onInvalidated);
    this.robot?.removeListener?.('change', this.onRobotChanged);
    await this.cancel('disposed');
  }
}

module.exports = { MusicDanceDriver, samePlayingMedia };
