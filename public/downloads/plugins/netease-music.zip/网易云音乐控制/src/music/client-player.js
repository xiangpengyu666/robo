'use strict';

const path = require('node:path');
const { readMediaStatus, controlMedia, mediaSourceIds } = require('../desktop/media');
const { NetEaseClientChannel } = require('./client-channel');
const failure = (code, userMessage) => Object.assign(new Error(userMessage), { code, userMessage });
const applicationKey = app => JSON.stringify([app?.path || '', app?.aumid || '', app?.args || [], app?.name || '']);
const check = signal => { if (signal?.aborted) throw failure('ABORTED', '操作已停止。'); };
const throwIfAborted = (error, signal) => {
  check(signal);
  if (error?.code === 'ABORTED' || error?.name === 'AbortError') throw error;
};
function clientMedia(state, controls, { strict = false } = {}) {
  if (!/^[1-9]\d*$/.test(state?.songId) || !state.title || !state.artist) return null;
  const clean = value => typeof value === 'string' ? value.replace(/[\x00-\x1f]/g, ' ').trim().slice(0, 500) : '';
  if (strict && (typeof state.songId !== 'string' || !/^[1-9]\d{0,14}$/.test(state.songId)
    || !Number.isSafeInteger(Number(state.songId)) || ![1, 2].includes(state.state) || !clean(state.title) || !clean(state.artist))) return null;
  const status = state.state === 2 ? 'playing' : state.state === 1 ? 'paused' : 'changing';
  return { sourceId: 'cloudmusic.exe', songId: state.songId, title: strict ? clean(state.title) : state.title,
    artist: strict ? clean(state.artist) : state.artist, album: strict ? clean(state.album) : state.album,
    status, positionMs: null, controls: controls || {} };
}

// The official desktop client is the only playback owner. Search/API resource
// authorization does not grant background control of that client's queue.
class NetEaseClientPlayer {
  constructor({ read = readMediaStatus, control = controlMedia, channel = new NetEaseClientChannel() } = {}) {
    this.readSession = read;
    this.controlSession = control;
    this.channel = channel;
    this.app = null;
    this.lastMedia = null;
    this.observedAt = 0;
    this.applicationGeneration = 0;
    this.applicationIdentity = applicationKey(null);
  }
  setApplication(app) {
    const identity = applicationKey(app);
    if (this.applicationIdentity !== identity) {
      ++this.applicationGeneration; this.lastMedia = null; this.observedAt = 0;
      this.channel.dispose();
    }
    this.applicationIdentity = identity;
    this.app = app;
  }
  launchArguments() { return this.channel.launchArguments?.() || []; }
  snapshot() {
    return { provider: '网易云音乐', playbackOwner: 'desktop_client',
      capabilities: { search: true, playSongInBackground: this.channel.ready === true, controls: this.lastMedia?.controls || {} },
      observedAt: this.observedAt, media: this.lastMedia };
  }
  async read(options = {}) {
    check(options.signal);
    const app = this.app, generation = this.applicationGeneration;
    const current = () => generation === this.applicationGeneration;
    const commit = media => {
      check(options.signal);
      if (!current()) return null;
      this.lastMedia = media; this.observedAt = Date.now(); return media;
    };
    if (options.preferClient === true && app) {
      const sources = mediaSourceIds(app);
      const isClient = typeof app.path === 'string' && path.win32.basename(app.path).toLowerCase() === 'cloudmusic.exe'
        && !app.args?.length && !app.aumid && sources.length > 0;
      if (isClient) {
        try {
          const state = await this.channel.read(app, options);
          check(options.signal); if (!current()) return null;
          const sameChannel = this.channel.ready === true && (!('identity' in this.channel) || this.channel.identity === app.path);
          const sameSource = state?.sourceId == null || sources.some(id => id.toLowerCase() === String(state.sourceId).toLowerCase());
          const controls = sources.some(id => id.toLowerCase() === String(this.lastMedia?.sourceId || '').toLowerCase()) ? this.lastMedia.controls : {};
          const media = sameChannel && sameSource ? clientMedia(state, controls, { strict: true }) : null;
          if (media) return commit(media);
        } catch (error) { throwIfAborted(error, options.signal); }
      }
      check(options.signal); if (!current()) return null;
      // This fallback is one independent SMTC read. Calling read() again would
      // retry the failed client channel and pay both costs for the same query.
      const media = await this.readSession(app, options);
      if (!current()) { check(options.signal); return null; }
      const sameSource = media == null || sources.some(id => id.toLowerCase() === String(media.sourceId || '').toLowerCase());
      return commit(sameSource ? media : null);
    }
    let media = app ? await this.readSession(app, options) : null;
    check(options.signal); if (!current()) return null;
    if (app) {
      try {
        const state = await this.channel.read(app, options);
        check(options.signal); if (!current()) return null;
        media = clientMedia(state, media?.controls) || media;
      } catch (error) { throwIfAborted(error, options.signal); }
    }
    return commit(media);
  }
  async prepare(song, options) { return this.channel.prepare(this.app, song, options); }
  async play(song, options) { return this.channel.play(this.app, song, options); }
  async close(options) { return this.channel.close(this.app, options); }
  async control(action, { signal, submitted = () => {} } = {}) {
    if (!['pause', 'resume', 'stop'].includes(action)) throw failure('MUSIC_ACTION_UNSUPPORTED', '这项音乐操作暂未接通。');
    const before = await this.read({ signal });
    if (!before) throw failure('MUSIC_SESSION_UNAVAILABLE', '暂时读不到网易云客户端的播放状态，这次没有操作。');
    const expected = { pause: 'paused', resume: 'playing', stop: 'stopped' }[action];
    if (before.status === expected) return before;
    const capability = { pause: 'canPause', resume: 'canPlay', stop: 'canStop' }[action];
    if (!before.controls[capability]) throw failure('MUSIC_CONTROL_UNAVAILABLE', '网易云客户端当前不支持这项后台控制，这次没有操作。');
    if (signal?.aborted) throw failure('ABORTED', '操作已停止。');
    submitted();
    const result = await this.controlSession(this.app, action, { signal });
    if (!result?.accepted) throw failure('MUSIC_CONTROL_REJECTED', '网易云客户端未确认接受这次控制请求。');
    // An accepted request is not a completion receipt. Refresh the actual
    // client state, without retrying the mutation.
    for (let i = 0; i < 3; i++) {
      if (signal?.aborted) throw failure('ABORTED', '操作已停止。');
      const media = await this.read({ signal });
      if (media?.status === expected) return media;
    }
    return this.lastMedia;
  }
  async dispose() { this.channel.dispose(); } // Disconnect only; never stop the user's music.
}
module.exports = { NetEaseClientPlayer };
