'use strict';
// A private pipe, never a command-line argument, carries the user's credentials.
// The official CLI writes its encrypted credential store in the isolated home.
let input='';
process.stdin.setEncoding('utf8');
process.stdin.on('data',chunk=>{input+=chunk;if(input.length>24000)process.exit(2);});
process.stdin.on('end',()=>{
  try{
    const {key,value}=JSON.parse(input);input='';
    if(!['appId','privateKey'].includes(key)||typeof value!=='string'||value.length>8192)process.exit(2);
    process.argv=[process.execPath,require('node:path').join(__dirname,'index.js'),'config','set',key,value];
    // Config writes can echo key prefixes. Do not propagate any output.
    process.stdout.write=()=>true;process.stderr.write=()=>true;
    require('./index.js');
  }catch{process.exitCode=2;}
});
