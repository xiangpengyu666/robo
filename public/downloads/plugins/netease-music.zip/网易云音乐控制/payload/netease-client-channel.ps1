param([Parameter(Mandatory = $true)][string]$RequestBase64)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
try {
  $musicRequest = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($RequestBase64)) | ConvertFrom-Json
  $musicPath = [IO.Path]::GetFullPath([string]$musicRequest.path)
  $musicPort = [int]$musicRequest.port
  if ([IO.Path]::GetFileName($musicPath) -ine 'cloudmusic.exe' -or !(Test-Path -LiteralPath $musicPath -PathType Leaf) -or $musicPort -lt 1024 -or $musicPort -gt 65535 -or $musicRequest.action -notin @('inspect','launch')) { throw 'Invalid client request' }
  $musicProcesses = @(Get-CimInstance Win32_Process -Filter "Name='cloudmusic.exe'" | Where-Object { $_.ExecutablePath -ieq $musicPath })
  $musicListeners = @(Get-NetTCPConnection -State Listen -LocalPort $musicPort -ErrorAction SilentlyContinue)
  $musicReady = $musicListeners.Count -eq 1 -and $musicListeners[0].LocalAddress -eq '127.0.0.1' -and $musicListeners[0].OwningProcess -in @($musicProcesses.ProcessId)
  if ($musicRequest.action -eq 'launch') {
    if ($musicListeners.Count -gt 0 -and !$musicReady) { throw 'Control port belongs to another process' }
    # Never kill/restart a running client, send a foreground protocol, or change
    # client settings. This launch affects only a fully exited client.
    if ($musicProcesses.Count -eq 0) {
      Start-Process -FilePath $musicPath -WorkingDirectory ([IO.Path]::GetDirectoryName($musicPath)) -WindowStyle Hidden -ArgumentList @('--force-show-window=off', '--remote-debugging-address=127.0.0.1', "--remote-debugging-port=$musicPort") | Out-Null
    }
  }
  @{ ok=$true; running=($musicProcesses.Count -gt 0); ready=[bool]$musicReady } | ConvertTo-Json -Compress
} catch { '{"ok":false}' }
