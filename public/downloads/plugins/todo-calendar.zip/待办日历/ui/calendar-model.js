'use strict';
// Calendar days are local dates. Adding days through Date preserves DST boundaries.
(function (root) {
  const dateKey = value => {
    const date = value instanceof Date ? value : new Date(value);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };
  const dayDate = key => {
    const [year, month, day] = key.split('-').map(Number);
    return new Date(year, month - 1, day, 12);
  };
  const addDays = (key, count) => { const date = dayDate(key); date.setDate(date.getDate() + count); return dateKey(date); };
  const weekStart = key => { const date = dayDate(key); return addDays(key, -((date.getDay() + 6) % 7)); };
  const monthStart = key => `${key.slice(0, 7)}-01`;
  const days = (key, mode = 'month') => {
    const start = mode === 'week' ? weekStart(key) : weekStart(monthStart(key));
    return Array.from({ length: mode === 'week' ? 7 : 42 }, (_, index) => addDays(start, index));
  };
  const shiftPeriod = (key, count, mode = 'month') => {
    if (mode === 'week') return addDays(key, count * 7);
    const date = dayDate(key), day = date.getDate();
    date.setDate(1); date.setMonth(date.getMonth() + count);
    const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    date.setDate(Math.min(day, last)); return dateKey(date);
  };
  const validDayKey = key => {
    if (typeof key !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(key)
      || dateKey(dayDate(key)) !== key) throw new RangeError('Invalid calendar day');
    return key;
  };
  // A board starts on any day and moves a day at a time, without snapping to a week.
  const dayWindow = (startKey, count = 3) => {
    validDayKey(startKey);
    if (!Number.isInteger(count) || count < 1 || count > 366) throw new RangeError('Invalid calendar window size');
    return Array.from({ length: count }, (_, index) => validDayKey(addDays(startKey, index)));
  };
  const shiftDayWindow = (startKey, count = 1) => {
    validDayKey(startKey);
    if (!Number.isInteger(count)) throw new RangeError('Invalid calendar day shift');
    return validDayKey(addDays(startKey, count));
  };
  const records = personal => [...(personal?.todos || []).map(item => ({ ...item, kind: 'todo' })),
    ...(personal?.reminders || []).map(item => ({ ...item, kind: 'reminder' }))];
  // Delivery records a notification; only an explicit completion finishes the work.
  const isPending = item => (item?.kind === 'todo' || item?.kind === 'reminder') && item.completedAt == null;
  // Undated tasks remain actionable; scheduled tasks expire at their scheduled time.
  const isUpcomingPending = (item, now = Date.now()) => isPending(item)
    && (item.dueAt == null || Number.isFinite(item.dueAt) && item.dueAt > now);
  const matches = (item, filter, query) => (!query || item.text.toLocaleLowerCase().includes(query.toLocaleLowerCase()))
    && (filter === 'all' || filter === 'reminder' && item.kind === 'reminder'
      || filter === 'pending' && isPending(item)
      || filter === 'completed' && (item.kind === 'todo' || item.kind === 'reminder') && item.completedAt != null);
  const byDay = (items, key) => items.filter(item => Number.isFinite(item.dueAt) && dateKey(item.dueAt) === key)
    .sort((a, b) => a.dueAt - b.dueAt || a.text.localeCompare(b.text, 'zh-CN'));
  // Fixed thresholds keep the same workload shade across different weeks/months.
  const busyLevel = count => {
    if (!Number.isInteger(count) || count < 0) throw new RangeError('Invalid calendar task count');
    return count === 0 ? 0 : Math.min(4, Math.ceil(count / 2));
  };
  const daySummary = (items, key) => {
    validDayKey(key);
    const scheduled = byDay(items, key), pending = scheduled.filter(isPending).length;
    return { items: scheduled, total: scheduled.length, pending, busyLevel: busyLevel(pending) };
  };
  const api = { dateKey, dayDate, addDays, weekStart, monthStart, days, shiftPeriod,
    dayWindow, shiftDayWindow, records, isPending, isUpcomingPending, matches, byDay, busyLevel, daySummary };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RoboCalendarModel = api;
})(typeof window === 'object' ? window : globalThis);
