'use strict';
window.FangzaiPersonalUI = class {
  constructor(api, host) {
    this.api = api; this.host = host; this.data = {}; this.kind = 'todo'; this.editing = null;
    this.saving = false; this.mode = 'week'; this.renderKey = ''; this.pending = new Set();
    this.model = window.RoboCalendarModel;
    this.selected = this.model.dateKey(new Date()); this.anchor = this.selected;
    this.columns = 3; this.weekAnchor = this.model.addDays(this.selected, -1);
    this.$ = id => host.querySelector('#' + id);
    this.summaryTimer = setInterval(() => {
      if (this.host.isConnected && this.host.getClientRects().length) this.render();
    }, 1000);
    this.mailSuggestionsHost = this.$('calendarMailSuggestions');
    this.$('personalBack').addEventListener('click', () => {
      if (!this.$('personalForm').hidden) this.closeEditor();
      else window.fangzaiShell?.navigate('tools');
    });
    this.$('calendarUnscheduledNew').addEventListener('click', () => this.edit(null, false));
    this.$('calendarDayNew').addEventListener('click', () => this.edit());
    this.$('calendarToday').addEventListener('click', () => {
      this.selected = this.model.dateKey(new Date()); this.anchor = this.selected; this.centerWeek(); this.render(true);
    });
    for (const [id, count] of [['calendarPrevious', -1], ['calendarNext', 1]]) this.$(id).addEventListener('click', () => {
      if (this.mode === 'week') {
        this.weekAnchor = this.model.shiftDayWindow(this.weekAnchor, count);
        const visible = this.model.dayWindow(this.weekAnchor, this.columns);
        if (!visible.includes(this.selected)) this.selected = count > 0 ? visible[0] : visible.at(-1);
      } else { this.anchor = this.model.shiftPeriod(this.anchor, count, 'month'); this.selected = this.anchor; }
      this.render(true);
    });
    for (const button of host.querySelectorAll('[data-calendar-mode]')) button.addEventListener('click', () => {
      this.mode = button.dataset.calendarMode; this.anchor = this.selected; this.centerWeek();
      this.host.querySelector('.calendar-scroll').scrollTop = 0; this.render(true);
    });
    this.$('personalCancelEdit').addEventListener('click', () => this.closeEditor());
    this.$('personalDeleteEdit').addEventListener('click', () => { if (this.editing) void this.remove(this.editing); });
    this.$('personalText').addEventListener('input', () => this.validate());
    this.$('personalTime').addEventListener('input', () => this.validate());
    this.$('personalClearTime').addEventListener('click', () => { this.$('personalTime').value = ''; this.validate(); });
    this.$('personalForm').addEventListener('submit', event => { event.preventDefault(); void this.save(); });
    this.$('personalForm').addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); this.closeEditor(); } });
    this.$('calendarEditor').addEventListener('cancel', event => { event.preventDefault(); this.closeEditor(); });
    this.$('personalSearch').addEventListener('input', () => this.render(true));
    if (window.ResizeObserver) {
      this.resizeObserver = new ResizeObserver(() => {
        if (this.columnCount() !== this.columns) this.render(true);
      });
      this.resizeObserver.observe(this.$('calendarGrid').parentElement);
      this.resizeObserver.observe(this.host.querySelector('.calendar-scroll'));
      this.resizeObserver.observe(this.mailSuggestionsHost);
      this.resizeObserver.observe(this.$('calendarUnscheduled'));
    }
  }
  show() {
    void this.markRemindersViewed();
    this.render(true);
  }
  async markRemindersViewed() {
    if (!(this.data.reminders || []).some(item => item.deliveredAt != null && item.viewedAt == null)) return;
    try { await this.api.voicePersonal({ action: 'view_reminders' }); } catch { /* Retried on the next visit. */ }
  }
  update(personal) { this.data = personal || {}; this.render(); }
  notice(text) {
    this.$('personalNotice').textContent = text || '';
    this.$('personalEditorNotice').textContent = text || '';
  }
  columnCount() {
    const width = this.$('calendarGrid').parentElement.clientWidth;
    return width ? Math.max(1, Math.min(4, Math.floor((width - 60 + 12) / 232))) : this.columns;
  }
  centerWeek() { this.weekAnchor = this.model.addDays(this.selected, -Math.floor((this.columns - 1) / 2)); }
  localTime(at) { const date = new Date(at); return new Date(at - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16); }
  labelTime(at) { return new Date(at).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }); }
  defaultTime() {
    const date = this.model.dayDate(this.selected); date.setHours(9, 0, 0, 0);
    if (this.selected === this.model.dateKey(new Date()) && date.getTime() <= Date.now()) date.setTime(Math.ceil((Date.now() + 60000) / 1800000) * 1800000);
    return date.getTime() > Date.now() ? this.localTime(date.getTime()) : '';
  }
  edit(item = null, scheduled = true) {
    if (this.saving) return;
    // Existing reminders keep their storage/API kind; all new calendar entries are todos.
    this.kind = item?.kind || 'todo';
    this.editing = item ? { ...item, displayTime: Number.isFinite(item.dueAt) ? this.localTime(item.dueAt) : '' } : null;
    this.returnFocus = document.activeElement;
    this.returnFocusKey = this.returnFocus?.dataset.calendarFocus;
    this.$('personalForm').hidden = false; this.$('personalForm').scrollTop = 0;
    this.$('personalText').value = item?.text || '';
    this.$('personalTime').value = this.editing?.displayTime ?? (scheduled ? this.defaultTime() : '');
    this.$('personalDeleteEdit').hidden = !item;
    this.$('personalSave').textContent = item ? '保存修改' : '添加';
    this.notice(''); this.paintEditor();
    if (!this.$('calendarEditor').open) this.$('calendarEditor').showModal();
    this.$('personalText').focus();
  }
  paintEditor() {
    this.$('personalEditorTitle').textContent = `${this.editing ? '编辑' : '添加'}待办`;
    this.$('personalForm').dataset.kind = this.kind;
    this.$('personalTextLabel').textContent = '待办内容';
    this.$('personalText').placeholder = '准备做什么？';
    this.$('personalText').maxLength = 200;
    this.$('personalTimeLabel').textContent = '时间';
    this.$('personalTime').required = false; this.$('personalClearTime').hidden = false;
    this.validate();
  }
  closeEditor() {
    if (this.saving) return;
    this.editing = null; this.$('calendarEditor').close(); this.$('personalForm').hidden = true;
    this.$('personalText').value = ''; this.$('personalTime').value = ''; this.render(true);
    const replacement = this.returnFocus?.isConnected && this.host.contains(this.returnFocus) && this.returnFocus.getClientRects().length ? this.returnFocus
      : [...this.host.querySelectorAll('[data-calendar-focus]')].find(control => control.dataset.calendarFocus === this.returnFocusKey && control.getClientRects().length);
    const add = this.mode === 'week' ? this.$('calendarGrid').querySelector(`.calendar-cell[data-date="${this.selected}"] .calendar-column-add`) : this.$('calendarDayNew');
    (replacement || add || this.$('calendarToday')).focus({ preventScroll: true });
  }
  validate() {
    const content = this.$('personalText').value.trim(), value = this.$('personalTime').value;
    const time = value ? new Date(value).getTime() : NaN;
    const unchangedTime = this.editing && value === this.editing.displayTime;
    const validTime = !value || Number.isFinite(time) && (unchangedTime || time > Date.now());
    const valid = Boolean(content && content.length <= 200 && validTime);
    this.$('personalSave').disabled = this.saving || !valid;
    this.$('personalTimeHint').textContent = !value ? '未安排'
      : !validTime ? '请选择未来的时间' : '';
    this.$('personalTimeHint').classList.toggle('is-invalid', !validTime);
    this.$('personalTime').setAttribute('aria-invalid', String(!validTime));
    this.$('personalCount').textContent = `${this.$('personalText').value.length} / 200`; return valid;
  }
  setBusy(value) {
    this.saving = value;
    for (const input of this.$('personalForm').querySelectorAll('input,textarea,select,button')) input.disabled = value;
    this.$('personalBack').disabled = value; this.validate();
  }
  async save() {
    if (this.saving || !this.validate()) return;
    const kind = this.kind, editing = this.editing, value = this.$('personalTime').value;
    const changedTime = !editing ? Boolean(value) : value !== editing.displayTime;
    const args = { text: this.$('personalText').value.trim(), ...(editing ? { id: editing.id, expectedRevision: editing.revision ?? 1 } : {}),
      ...(changedTime ? { dueAt: value ? new Date(value).toISOString() : null } : {}) };
    this.setBusy(true); let saved = false;
    try {
      const result = await this.api.voicePersonal({ action: `${editing ? 'update' : 'create'}_${kind}`, args });
      saved = result?.ok; this.notice(saved ? '已保存' : result?.error || '保存失败，内容已保留');
      if (saved) {
        this.applyReceipt(kind, result);
        if (value) { this.selected = this.model.dateKey(new Date(value)); this.anchor = this.selected; this.centerWeek(); }
      }
    } catch { this.notice('保存未完成，输入内容已保留'); }
    finally {
      this.setBusy(false);
      if (saved) this.closeEditor();
      else this.$('personalText').focus({ preventScroll: true });
    }
  }
  async remove(item) {
    if (this.saving) return; this.setBusy(true); let deleted = false;
    try {
      const response = await this.api.voicePersonal({ action: `delete_${item.kind}s`, args: { ids: [item.id], expectedRevisions: { [item.id]: item.revision ?? 1 } } });
      deleted = response?.ok;
      if (!deleted) { this.notice(response?.error || '删除未完成，请重试'); return; }
      this.notice('已删除');
    } catch { this.notice('删除未完成，请重试'); }
    finally {
      this.setBusy(false);
      if (deleted && this.editing?.id === item.id) this.closeEditor();
      else if (!deleted && this.$('calendarEditor').open) this.$('personalText').focus({ preventScroll: true });
    }
  }
  async complete(item, button) {
    const key = `${item.kind}:${item.id}`;
    if (this.saving || this.pending.has(key)) { button.checked = item.completedAt != null; return; }
    // Disabling a focused checkbox blurs it before the service publishes its update.
    const restoreFocus = document.activeElement === button, focusKey = button.dataset.calendarFocus;
    const day = button.closest('.calendar-cell')?.dataset.date || this.selected;
    this.pending.add(key); button.disabled = true;
    try {
      const result = await this.api.voicePersonal({ action: `update_${item.kind}`, args: { id: item.id, expectedRevision: item.revision ?? 1, completed: item.completedAt == null } });
      if (!result?.ok) { button.checked = item.completedAt != null; this.notice(result?.error || '更新未完成，请重试'); }
      else { this.applyReceipt(item.kind, result); this.notice(''); }
    } catch { button.checked = item.completedAt != null; this.notice('更新未完成，请重试'); }
    finally {
      this.pending.delete(key); button.disabled = false; this.render(true);
      if (restoreFocus && (document.activeElement === document.body || document.activeElement === button)) {
        const replacement = [...this.host.querySelectorAll('[data-calendar-focus]')].find(control => control.dataset.calendarFocus === focusKey)
          || this.$('calendarGrid').querySelector(`[data-calendar-day="${day}"]`);
        replacement?.focus({ preventScroll: true });
      }
    }
  }
  applyReceipt(kind, response) {
    const receipt = response?.result;
    if (receipt?.currentState === 'deleted') return;
    const currentKind = receipt?.currentRecord && ['todo', 'reminder'].includes(receipt.currentKind) ? receipt.currentKind : null;
    const savedKind = currentKind || (receipt?.todo ? 'todo' : receipt?.reminder ? 'reminder' : kind);
    const item = currentKind ? receipt.currentRecord : receipt?.[savedKind], collection = `${savedKind}s`;
    if (!item?.id) return;
    const other = (this.data[savedKind === 'todo' ? 'reminders' : 'todos'] || []).find(record => record.id === item.id);
    if (other && (other.revision ?? 1) >= (item.revision ?? 1)) return;
    if (!Array.isArray(this.data[collection])) this.data[collection] = [];
    const index = this.data[collection].findIndex(record => record.id === item.id);
    if (index < 0) this.data[collection].push(item);
    else if ((this.data[collection][index].revision ?? 1) <= (item.revision ?? 1)) this.data[collection][index] = item;
    // The service confirms the atomic conversion before the old collection is changed locally.
    if (savedKind === 'todo' && (receipt.convertedFrom === 'reminder' || currentKind === 'todo' && kind === 'reminder')) {
      this.data.reminders = (this.data.reminders || []).filter(record => record.id !== item.id);
    }
  }
  selectDay(key, focus = false) {
    this.selected = key;
    if (this.mode === 'week') {
      if (!this.model.dayWindow(this.weekAnchor, this.columns).includes(key)) this.weekAnchor = key;
    } else if (key.slice(0, 7) !== this.anchor.slice(0, 7)) this.anchor = key;
    this.render(true);
    if (focus) this.$('calendarGrid').querySelector(`[data-calendar-day="${key}"]`)?.focus();
  }
  dayKeydown(event, key) {
    const offset = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[event.key];
    if (offset !== undefined) { event.preventDefault(); this.selectDay(this.model.addDays(key, offset), true); }
    else if (event.key === 'Home') { event.preventDefault(); this.selectDay(this.model.weekStart(key), true); }
    else if (event.key === 'End') { event.preventDefault(); this.selectDay(this.model.addDays(this.model.weekStart(key), 6), true); }
  }
  renderItem(item, host) {
    const row = document.createElement('article'); row.className = 'personal-item calendar-agenda-item'; row.dataset.id = item.id; row.dataset.calendarItem = item.id;
    row.classList.toggle('is-completed', item.completedAt != null);
    const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = item.completedAt != null;
    checkbox.dataset.calendarFocus = `check:${item.kind}:${item.id}`; checkbox.disabled = this.pending.has(`${item.kind}:${item.id}`);
    checkbox.setAttribute('aria-label', `${checkbox.checked ? '已完成，取消完成' : '标记完成'}：${item.text}`);
    checkbox.addEventListener('change', () => this.complete(item, checkbox)); row.append(checkbox);
    const body = document.createElement('button'), content = document.createElement('p'), time = document.createElement('small');
    body.type = 'button'; body.className = 'personal-item-body calendar-item-edit';
    body.dataset.calendarFocus = `edit:${item.kind}:${item.id}`;
    body.disabled = this.pending.has(`${item.kind}:${item.id}`);
    body.setAttribute('aria-label', `编辑待办：${item.text}`);
    content.textContent = item.text;
    time.textContent = item.dueAt != null ? this.labelTime(item.dueAt) : '';
    time.hidden = !time.textContent; body.append(content, time); body.addEventListener('click', () => {
      if (Number.isFinite(item.dueAt)) this.selected = this.model.dateKey(item.dueAt);
      this.edit(item);
    }); row.append(body); host.append(row);
  }
  empty(host, text) { const empty = document.createElement('p'); empty.className = 'calendar-empty'; empty.textContent = text; host.append(empty); }
  render(force = false) {
    const query = this.$('personalSearch').value.trim().toLocaleLowerCase(), today = this.model.dateKey(new Date());
    const columns = this.columnCount();
    if (columns !== this.columns) { this.columns = columns; this.centerWeek(); }
    const now = Date.now();
    const records = this.model.records(this.data);
    const pendingCount = records.filter(item => this.model.isUpcomingPending(item, now)).length;
    const key = JSON.stringify([pendingCount, this.data, this.mode, this.selected, this.anchor, this.weekAnchor, this.columns, query, today]);
    if (!force && key === this.renderKey) return; this.renderKey = key;
    if (this.data.error) this.notice(this.data.error);
    // Completion stays visible; workload and month totals use saved records regardless of search.
    const items = records.filter(item => this.model.matches(item, 'all', query));
    this.$('calendarSummary').textContent = `${pendingCount} 项待完成`;
    this.$('calendarSummary').dataset.empty = String(pendingCount === 0);
    for (const button of this.host.querySelectorAll('[data-calendar-mode]')) button.setAttribute('aria-pressed', String(button.dataset.calendarMode === this.mode));
    const visible = this.mode === 'week' ? this.model.dayWindow(this.weekAnchor, this.columns) : this.model.days(this.anchor, 'month');
    const shortDate = day => this.model.dayDate(day).toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' });
    const anchorDate = this.model.dayDate(this.anchor);
    this.$('calendarPeriod').textContent = this.mode === 'month' ? `${anchorDate.getFullYear()}年 ${anchorDate.getMonth() + 1}月`
      : visible.length === 1 ? shortDate(visible[0]) : `${shortDate(visible[0])} — ${shortDate(visible.at(-1))}`;
    this.$('calendarTodayDate').textContent = `今天 · ${shortDate(today)}`;
    this.$('calendarPrevious').setAttribute('aria-label', this.mode === 'month' ? '上个月' : '向前一天');
    this.$('calendarNext').setAttribute('aria-label', this.mode === 'month' ? '下个月' : '向后一天');
    this.$('calendarWeekdays').hidden = this.mode === 'week';
    this.$('calendarAgenda').hidden = this.mode === 'week';
    const grid = this.$('calendarGrid'), active = document.activeElement;
    const focused = this.host.contains(active) ? active.dataset.calendarFocus : null;
    const focusedDay = active?.closest('.calendar-cell')?.dataset.date || this.selected;
    const scrollPositions = new Map([...this.host.querySelectorAll('[data-calendar-list]')].map(list => [list.dataset.calendarList, list.scrollTop]));
    const scroll = this.host.querySelector('.calendar-scroll'), scrollTop = scroll.scrollTop;
    scroll.dataset.mode = this.mode;
    grid.replaceChildren(); grid.dataset.mode = this.mode;
    grid.style.setProperty('--calendar-columns', String(this.columns));
    grid.setAttribute('aria-label', this.mode === 'month' ? '月日历' : '每日待办看板');
    const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
    for (const day of visible) {
      const date = this.model.dayDate(day), summary = this.model.daySummary(records, day);
      const dayItems = this.model.byDay(items, day), cell = document.createElement('div');
      cell.className = 'calendar-cell'; cell.dataset.date = day; cell.dataset.busy = String(summary.busyLevel);
      cell.classList.toggle('is-selected', day === this.selected); cell.classList.toggle('is-today', day === today);
      cell.classList.toggle('is-outside', this.mode === 'month' && day.slice(0, 7) !== this.anchor.slice(0, 7));
      const button = document.createElement('button'); button.type = 'button'; button.className = 'calendar-day';
      button.dataset.calendarDay = day; button.dataset.calendarFocus = `day:${day}`;
      button.setAttribute('aria-label', `${date.getMonth() + 1}月${date.getDate()}日，星期${weekdays[date.getDay()]}${day === today ? '，今天' : ''}，${summary.total} 项，${summary.pending} 项待完成`);
      button.setAttribute('aria-pressed', String(day === this.selected)); button.tabIndex = day === this.selected ? 0 : -1;
      button.addEventListener('click', () => this.selectDay(day, true)); button.addEventListener('keydown', event => this.dayKeydown(event, day));
      if (this.mode === 'month') {
        const number = document.createElement('span'); number.className = 'calendar-date-number'; number.textContent = String(date.getDate());
        const count = document.createElement('span'); count.className = 'calendar-day-count'; count.dataset.calendarCount = String(summary.total);
        count.textContent = String(summary.total); count.hidden = summary.total === 0;
        count.title = `${summary.total} 项待办`; count.setAttribute('aria-hidden', 'true');
        button.append(number, count); cell.append(button);
      } else {
        button.textContent = `星期${weekdays[date.getDay()]}${day === today ? '（今天）' : ''}`;
        cell.append(button);
        const list = document.createElement('div'); list.className = 'calendar-column-list'; list.dataset.calendarList = day;
        for (const item of dayItems) this.renderItem(item, list);
        if (!dayItems.length) this.empty(list, query ? '无匹配事项' : '暂无待办');
        cell.append(list);
        const add = document.createElement('button'); add.type = 'button'; add.className = 'calendar-column-add'; add.textContent = '＋';
        add.setAttribute('aria-label', `为${shortDate(day)}添加待办`);
        add.addEventListener('click', () => { this.selected = day; this.edit(); }); cell.append(add);
      }
      grid.append(cell);
    }
    const selectedDate = this.model.dayDate(this.selected), agenda = this.$('personalList'); agenda.replaceChildren();
    this.$('calendarSelectedDate').textContent = shortDate(this.selected);
    this.$('calendarSelectedWeekday').textContent = `星期${weekdays[selectedDate.getDay()]}`;
    const scheduled = this.model.byDay(items, this.selected); this.$('calendarDayCount').textContent = `${scheduled.length} 项`;
    if (this.mode === 'month') {
      for (const item of scheduled) this.renderItem(item, agenda);
      if (!scheduled.length) this.empty(agenda, query ? '无匹配事项' : '暂无待办');
    }
    const allUnscheduled = records.filter(item => item.dueAt == null);
    const unscheduled = items.filter(item => item.dueAt == null), inbox = this.$('calendarUnscheduledList'); inbox.replaceChildren();
    this.$('calendarUnscheduled').hidden = allUnscheduled.length === 0;
    this.$('calendarUnscheduledCount').textContent = String(allUnscheduled.length);
    for (const item of unscheduled) this.renderItem(item, inbox);
    if (!unscheduled.length && allUnscheduled.length) this.empty(inbox, '无匹配事项');
    for (const list of this.host.querySelectorAll('[data-calendar-list]')) list.scrollTop = scrollPositions.get(list.dataset.calendarList) || 0;
    if (focused) {
      const replacement = [...this.host.querySelectorAll('[data-calendar-focus]')].find(control => control.dataset.calendarFocus === focused)
        || grid.querySelector(`[data-calendar-day="${focusedDay}"]`) || grid.querySelector('[data-calendar-day]');
      replacement?.focus({ preventScroll: true });
    }
    this.host.querySelector('.calendar-scroll').scrollTop = scrollTop;
  }
};
