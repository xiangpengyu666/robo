'use strict';
const { EventEmitter } = require('node:events');
const { randomUUID } = require('node:crypto');
const { saveToolState, readToolState } = require('./tool-store');
const DEFAULTS = Object.freeze({ focus: 25, short_break: 5 });
const LABELS = Object.freeze({ focus: '番茄', short_break: '休息' });
const AUTO_BREAK_MS = 5 * 60000;
const FOCUS_FINISHED = '这轮番茄钟完成啦！现在开始休息一下吧~。';
const ROUND_FINISHED = '休息时间结束啦，已为你计入一次完成次数，请继续加油！';
const BREAK_FINISHED = '休息时间结束啦，请继续加油！';
const validSettings = settings => settings && Object.keys(DEFAULTS).every(key => Number.isInteger(settings[key]) && settings[key] >= 1 && settings[key] <= (key === 'focus' ? 180 : 60));
const empty = () => ({ version: 3, settings: { ...DEFAULTS }, phase: 'focus', status: 'idle', durationMs: DEFAULTS.focus * 60000, remainingMs: DEFAULTS.focus * 60000, deadline: null, completed: 0, notification: null, sessionId: null, cyclePending: false });
function validState(s) {
  return [1, 2, 3].includes(s?.version) && validSettings(s.settings) && (Object.hasOwn(LABELS, s.phase) || s.version === 1 && s.phase === 'long_break') && ['idle', 'running', 'paused', 'finished'].includes(s.status)
    && Number.isFinite(s.durationMs) && s.durationMs > 0 && s.durationMs <= 180 * 60000 && Number.isFinite(s.remainingMs) && s.remainingMs >= 0 && s.remainingMs <= s.durationMs
    && Number.isSafeInteger(s.completed) && s.completed >= 0 && (s.status !== 'running' || Number.isFinite(s.deadline))
    && (s.notification === null || typeof s.notification?.id === 'string' && typeof s.notification?.message === 'string')
    && (s.version !== 3 || typeof s.cyclePending === 'boolean' && (s.sessionId === null || typeof s.sessionId === 'string' && s.sessionId.length > 0));
}
class Pomodoro extends EventEmitter {
  constructor({ filePath, now = Date.now } = {}) {
    super(); this.filePath = filePath; this.now = now; this.error = null; this.notice = null;
    this.state = empty(); let loaded;
    try {
      loaded = readToolState(filePath, empty(), validState); this.state = loaded;
      if (loaded.version < 3) {
        // Older completed focus phases were already counted; their rest must not count again.
        const migrated = { ...loaded, version: 3, phase: loaded.phase === 'long_break' ? 'short_break' : loaded.phase,
          settings: { focus: loaded.settings.focus, short_break: loaded.settings.short_break }, cyclePending: false,
          sessionId: loaded.status === 'idle' ? null : typeof loaded.sessionId === 'string' && loaded.sessionId ? loaded.sessionId : randomUUID() };
        if (migrated.status === 'finished' && migrated.notification) migrated.notification = { ...migrated.notification,
          id: migrated.notification.id || randomUUID(), message: migrated.phase === 'focus' ? FOCUS_FINISHED : BREAK_FINISHED };
        if (migrated.status === 'finished' && !migrated.notification) {
          // A previously dismissed completion has no delivery left to settle.
          migrated.status = 'idle'; migrated.phase = 'focus'; migrated.deadline = null; migrated.sessionId = null;
          migrated.durationMs = migrated.remainingMs = migrated.settings.focus * 60000;
        }
        // Retain the readable old count and state if migration cannot be persisted.
        saveToolState(filePath, migrated); this.state = migrated;
      }
    }
    catch { this.error = loaded ? '番茄钟数据暂时无法更新，原记录已保留。' : '番茄钟数据暂时无法读取，原文件已保留。'; }
    this.lastSecond = null;
  }
  snapshot() {
    const s = structuredClone(this.state);
    s.remainingMs = s.status === 'running' ? Math.min(s.durationMs, Math.max(0, s.deadline - this.now())) : s.remainingMs;
    s.remainingSeconds = Math.ceil(s.remainingMs / 1000);
    s.nextPhase = s.phase === 'focus' ? 'short_break' : 'focus';
    return { ...s, error: this.error, notice: this.notice };
  }
  commit(next, transition) {
    if (this.error) throw new Error(this.error);
    saveToolState(this.filePath, next); this.state = next; this.notice = null; this.emit('change', this.snapshot(), transition);
  }
  tick() {
    if (this.error || this.state.status !== 'running') return;
    if (this.state.deadline <= this.now()) {
      const next = structuredClone(this.state);
      next.status = 'finished'; next.remainingMs = 0; next.deadline = null;
      const completedRound = next.phase === 'short_break' && next.cyclePending;
      if (completedRound) next.completed += 1;
      next.cyclePending = next.phase === 'focus';
      next.notification = { id: randomUUID(), message: next.phase === 'focus' ? FOCUS_FINISHED : completedRound ? ROUND_FINISHED : BREAK_FINISHED, createdAt: this.now() };
      // Persist completion once, including its notice, before any delivery.
      this.commit(next); this.emit('finished', this.snapshot()); return;
    }
    const second = this.snapshot().remainingSeconds;
    if (second !== this.lastSecond) { this.lastSecond = second; this.emit('change', this.snapshot()); }
  }
  settleCompletion(sessionId, notificationId) {
    const current = this.state;
    if (current.status !== 'finished' || !sessionId || !notificationId || current.sessionId !== sessionId || current.notification?.id !== notificationId) return null;
    const next = structuredClone(current);
    next.notification = null;
    if (next.phase === 'focus') {
      next.phase = 'short_break'; next.status = 'running'; next.durationMs = next.remainingMs = AUTO_BREAK_MS;
      next.deadline = this.now() + AUTO_BREAK_MS; next.sessionId = randomUUID();
    } else {
      next.phase = 'focus'; next.status = 'idle'; next.durationMs = next.remainingMs = next.settings.focus * 60000;
      next.deadline = null; next.sessionId = null; next.cyclePending = false;
    }
    this.commit(next, { completionSessionId: current.sessionId });
    return this.snapshot();
  }
  execute(args = {}, context = {}) {
    if (context.signal?.aborted) return { status: 'cancelled', message: '番茄钟操作已停止。' };
    try {
      if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(key => !['action', 'phase', 'focus', 'short_break'].includes(key))) throw new Error('番茄钟参数不正确。');
      this.tick();
      if (this.error) throw new Error(this.error);
      const next = structuredClone(this.state), action = args.action;
      if (action === 'get') {
        const s = this.snapshot(), time = `${Math.floor(s.remainingSeconds / 60)}分${s.remainingSeconds % 60}秒`;
        return { status: 'success', verified: true, action: 'get', pomodoro: s, message: s.status === 'idle' ? `番茄钟尚未开始，番茄时长${s.settings.focus}分钟。` : s.status === 'finished' ? `${LABELS[s.phase]}已结束。` : `${LABELS[s.phase]}${s.status === 'paused' ? '已暂停，' : '中，'}还剩${time}。` };
      }
      let message;
      if (action === 'configure') {
        for (const key of Object.keys(DEFAULTS)) if (args[key] !== undefined) next.settings[key] = args[key];
        if (!validSettings(next.settings)) throw new Error('番茄时长需为1～180分钟，休息时长需为1～60分钟的整数。');
        if (next.status === 'idle') next.remainingMs = next.durationMs = next.settings[next.phase] * 60000;
        message = next.status === 'running' || next.status === 'paused' ? '时长已保存，下次开始时生效。' : '番茄钟时长已保存。';
      } else if (action === 'start' || action === 'next') {
        if (['running', 'paused'].includes(next.status)) throw new Error('已有一段计时，请先继续或结束它。');
        if (action === 'next' && next.status !== 'finished') throw new Error('当前还没有完成的计时。');
        for (const key of Object.keys(DEFAULTS)) if (args[key] !== undefined) next.settings[key] = args[key];
        if (!validSettings(next.settings)) throw new Error('番茄时长需为1～180分钟，休息时长需为1～60分钟的整数。');
        const phase = action === 'next' ? this.snapshot().nextPhase : args.phase || 'focus';
        if (!Object.hasOwn(LABELS, phase)) throw new Error('请选择番茄或休息。');
        const continuingCycle = action === 'next' && next.phase === 'focus';
        next.cyclePending = continuingCycle && next.cyclePending;
        next.phase = phase; next.durationMs = next.remainingMs = continuingCycle ? AUTO_BREAK_MS : next.settings[phase] * 60000;
        next.status = 'running'; next.deadline = this.now() + next.durationMs; next.notification = null; next.sessionId = randomUUID();
        message = `已开始${next.durationMs / 60000}分钟${LABELS[phase]}。`;
      } else if (action === 'pause') {
        if (next.status !== 'running') throw new Error('当前没有正在进行的计时。');
        next.remainingMs = this.snapshot().remainingMs; next.deadline = null; next.status = 'paused'; message = '番茄钟已暂停。';
      } else if (action === 'resume') {
        if (next.status !== 'paused') throw new Error('当前没有暂停的计时。');
        next.deadline = this.now() + next.remainingMs; next.status = 'running'; message = '番茄钟已继续。';
      } else if (action === 'stop') {
        next.status = 'idle'; next.phase = 'focus'; next.deadline = null; next.remainingMs = next.durationMs = next.settings.focus * 60000; next.notification = null; next.sessionId = null; next.cyclePending = false;
        message = '番茄钟已结束，已完成的次数已保留。';
      } else if (action === 'dismiss') {
        const settled = this.settleCompletion(next.sessionId, next.notification?.id);
        if (settled) return { status: 'success', verified: true, action, pomodoro: settled, message: '已关闭番茄钟通知。' };
        next.notification = null; message = '已关闭番茄钟通知。';
      }
      else throw new Error('不支持这个番茄钟操作。');
      this.commit(next);
      return { status: 'success', verified: true, action, pomodoro: this.snapshot(), message };
    } catch (error) { return { status: 'failed', message: error.code ? '番茄钟状态未能保存，请检查磁盘空间后重试。' : error.message }; }
  }
}
module.exports = { Pomodoro, DEFAULTS, LABELS };
