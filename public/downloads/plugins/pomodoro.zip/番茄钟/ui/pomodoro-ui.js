'use strict';
(() => {
  const panel = document.getElementById('pomodoroWorkspace'), api = window.robotDemo;
  const labels = { focus: '番茄钟', short_break: '休息' };
  let state = null, selected = 'focus', busy = false, dirty = false, systemNotice = '';
  panel.innerHTML = `<header class="daily-heading tool-page-header"><button class="daily-button tool-back" data-back type="button">‹ 返回工具</button>
    <h1 class="tool-page-title">番茄钟</h1></header>
    <div class="pomodoro-layout"><div class="pomodoro-main">
      <div class="daily-tabs" role="group" aria-label="计时类型"><button data-phase="focus" type="button" aria-pressed="true">番茄钟</button><button data-phase="short_break" type="button" aria-pressed="false">单独休息</button></div>
      <div class="pomodoro-dial"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="pomodoro-track" cx="60" cy="60" r="54"/><circle id="pomodoroProgress" class="pomodoro-progress" cx="60" cy="60" r="54" stroke-dasharray="339.292" stroke-dashoffset="0"/></svg><div class="pomodoro-face"><span id="pomodoroPhase" class="pomodoro-phase">准备开始</span><strong id="pomodoroTime" class="pomodoro-time" role="timer" aria-label="剩余时间">25:00</strong><span id="pomodoroRounds" class="pomodoro-rounds">已完成 0 轮</span></div></div>
      <div class="pomodoro-actions"><button id="pomodoroPrimary" class="daily-button primary" type="button">开始番茄钟</button><button id="pomodoroStop" class="daily-button quiet" type="button" hidden>结束本轮</button></div>
      <p id="pomodoroNotice" class="daily-notice" role="status"></p></div>
      <details id="pomodoroSettingsDisclosure" class="pomodoro-settings pomodoro-settings-disclosure"><summary title="番茄钟结束后自动休息5分钟；单独休息时长可调整">时长设置 <span id="pomodoroDurations">25 / 5 分钟</span></summary><form id="pomodoroSettings">
        <label>番茄钟 <span><input name="focus" aria-label="番茄钟分钟数" type="number" min="1" max="180" step="1" value="25" required> 分钟</span></label>
        <label>单独休息 <span><input name="short_break" aria-label="单独休息分钟数" type="number" min="1" max="60" step="1" value="5" required> 分钟</span></label>
        <button class="daily-button" type="submit" hidden disabled>保存时长</button><p id="pomodoroSettingsHint" class="daily-hint" hidden>下一段生效</p>
      </form></details></div>`;
  const $ = id => panel.querySelector('#' + id);
  const settings = () => Object.fromEntries([...$('pomodoroSettings').querySelectorAll('input')].map(input => [input.name, Number(input.value)]));
  function render() {
    if (!state) return;
    const active = ['running', 'paused'].includes(state.status), phase = active || state.status === 'finished' ? state.phase : selected;
    const seconds = state.status === 'idle' ? state.settings[selected] * 60 : state.remainingSeconds;
    $('pomodoroTime').textContent = String(Math.floor(seconds / 60)).padStart(2, '0') + ':' + String(seconds % 60).padStart(2, '0');
    $('pomodoroPhase').textContent = state.status === 'running' ? (phase === 'focus' ? '番茄计时' : '休息中') : state.status === 'paused' ? '已暂停' : state.status === 'finished' ? labels[phase] + '完成' : selected === 'focus' ? '准备开始' : '准备休息';
    $('pomodoroRounds').textContent = `已完成 ${state.completed} 轮`;
    $('pomodoroProgress').setAttribute('stroke-dashoffset', String(339.292 * (state.status === 'idle' ? 0 : 1 - Math.min(1, seconds * 1000 / state.durationMs))));
    $('pomodoroPrimary').textContent = state.status === 'running' ? '暂停' : state.status === 'paused' ? '继续' : state.status === 'finished' ? (phase === 'focus' ? '即将开始休息' : '本轮即将结束') : '开始' + labels[selected];
    $('pomodoroStop').hidden = state.status === 'idle'; $('pomodoroStop').textContent = '结束';
    for (const button of panel.querySelectorAll('button')) button.disabled = busy || Boolean(state.error);
    $('pomodoroPrimary').disabled = busy || Boolean(state.error) || state.status === 'finished';
    panel.querySelector('[data-back]').disabled = false;
    for (const button of panel.querySelectorAll('[data-phase]')) { button.disabled = busy || active || state.status === 'finished' || Boolean(state.error); button.setAttribute('aria-pressed', String(button.dataset.phase === phase)); }
    for (const input of $('pomodoroSettings').querySelectorAll('input')) { input.disabled = busy || Boolean(state.error); if (!dirty) input.value = state.settings[input.name]; }
    $('pomodoroDurations').textContent = `${state.settings.focus} / ${state.settings.short_break} 分钟`;
    $('pomodoroSettings').querySelector('button[type=submit]').disabled = busy || Boolean(state.error) || !dirty;
    $('pomodoroSettings').querySelector('button[type=submit]').hidden = !dirty;
    $('pomodoroSettingsHint').hidden = !active || !dirty;
    const issue = state.error || state.notice || '';
    if (issue) $('pomodoroNotice').textContent = issue;
    else if (systemNotice && $('pomodoroNotice').textContent === systemNotice) $('pomodoroNotice').textContent = '';
    systemNotice = issue;
  }
  async function execute(args) {
    if (busy) return; busy = true; render();
    try { const response = await api.pomodoroAction(args); if (!response?.ok) $('pomodoroNotice').textContent = response?.error || '操作未完成，请重试。';
      else { state = response.result.pomodoro; if (['configure', 'start'].includes(args.action)) dirty = false; $('pomodoroNotice').textContent = args.action === 'configure' ? response.result.message : ''; } }
    catch { $('pomodoroNotice').textContent = '暂时无法连接番茄钟，请重试。'; }
    finally { busy = false; render(); }
  }
  panel.querySelector('[data-back]').addEventListener('click', () => window.fangzaiShell.navigate('tools'));
  for (const button of panel.querySelectorAll('[data-phase]')) button.addEventListener('click', () => { selected = button.dataset.phase; render(); });
  $('pomodoroPrimary').addEventListener('click', () => {
    if (!state) return;
    const action = { running: 'pause', paused: 'resume', finished: 'next', idle: 'start' }[state.status];
    if (action === 'start' && !$('pomodoroSettings').checkValidity()) { $('pomodoroSettingsDisclosure').open = true; $('pomodoroSettings').reportValidity(); return; }
    execute({ action, ...(action === 'start' ? { phase: selected, ...settings() } : {}) });
  });
  $('pomodoroStop').addEventListener('click', () => { selected = 'focus'; execute({ action: 'stop' }); });
  $('pomodoroSettings').addEventListener('input', () => { dirty = true; render(); });
  $('pomodoroSettings').addEventListener('submit', event => { event.preventDefault(); execute({ action: 'configure', ...settings() }); });
  const update = snapshot => { if (snapshot.voice?.pomodoro) { state = snapshot.voice.pomodoro; render(); } };
  api.subscribe(update); api.getState().then(update).catch(() => { $('pomodoroNotice').textContent = '番茄钟连接中，请稍后重试。'; });
})();
